 /**
 * Word Frequency Counter
 * Daniel Yu
 * April 11, 2025
 */
const fs = require('fs');

/**
 * Node class for initializing nodes
 */
class Node {
    constructor(data, count) {
        this.data = data;
        this.count = count;
        this.next = null;
    }
}

/**
 * LinkedList class for managing word data
 */
class LinkedList {
    constructor(head = null) {
        this.head = head;
        this.size = 0;
    }

    /**
     * Add word to the list or increment count if it already exists
     */
    push(data) {
        // Normalize word
        data = data.replace(/[^\w\s]|_/g, "").replace(/\s+/g, " ").toLowerCase();

        if (data === "") return;

        let current = this.head;

        while (current) {
            if (current.data === data) {
                current.count++;
                return;
            }
            current = current.next;
        }

        const node = new Node(data, 1);
        if (!this.head) {
            this.head = node;
        } else {
            current = this.head;
            while (current.next) {
                current = current.next;
            }
            current.next = node;
        }

        this.size++;
    }

    /**
     * Return top 20 words sorted by frequency
     */
    getTopWords(n = 20) {
        let sorted = [];
        let current = this.head;

        while (current) {
            sorted.push(current);
            current = current.next;
        }

        sorted.sort((a, b) => b.count - a.count);

        return sorted.slice(0, n);
    }
}

/**
 * Main program
 */
function main() {
    const args = process.argv.slice(2);
    if (args.length < 1) {
        console.error("Usage: node wordCounter.js <filename>");
        process.exit(1);
    }

    const filename = args[0];
    try {
        const text = fs.readFileSync(filename, 'utf8');
        const words = text.split(/\s+/);
        const list = new LinkedList();

        for (let word of words) {
            list.push(word);
        }

        const topWords = list.getTopWords();
        console.log(`Top ${topWords.length} words:\n`);
        for (const node of topWords) {
            console.log(node.data.padStart(18) + "\t" + node.count);
        }
    } catch (err) {
        console.error(`Error reading file "${filename}":`, err.message);
    }
}

main();
