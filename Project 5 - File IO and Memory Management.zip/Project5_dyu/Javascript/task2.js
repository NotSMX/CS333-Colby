/**
 * Memory Management in Javascript
 * Daniel Yu
 * April 10, 2025
 */

console.log("=== Memory Allocation Examples ===");

// Allocating memory
let name = "Alice"; // String allocation
let numbers = [1, 2, 3]; // Array allocation
let obj = { key: "value" }; // Object allocation
function greet() { return "Hi"; } // Function allocation

console.log(name, numbers, obj, greet());

// Creating and losing memory references
console.log("\n=== Releasing Memory Example ===");
let data = { user: "Bob" };
data = null; // Memory for the original object is now garbage

// Demonstrating function-scope GC
function createLargeArray() {
    let temp = new Array(1000000).fill(42); // Allocates large array
    console.log("Created large array inside function.");
}
createLargeArray(); // temp is GC'd after the function exits

// Intentional memory leak
console.log("\n=== Memory Leak Example ===");
let leaks = [];
function leakyFunction() {
    leaks.push(() => console.log("Still alive!")); // Closure keeps memory alive
}
for (let i = 0; i < 1000; i++) {
    leakyFunction();
}
console.log("Created closures that may prevent GC.");

// Simulating lost memory
console.log("\n=== Losing Memory Example ===");
let example = { a: { b: { c: {} } } };
example = null; // The whole object graph becomes unreachable

// Comparison with C-style manual allocation (conceptual comment)
/*
C version:
char* name = malloc(10 * sizeof(char));
strcpy(name, "Hello");
free(name);

JavaScript equivalent:
let name = "Hello"; // Automatically managed
*/

// Displaying final message
console.log("\nJavaScript manages memory automatically using garbage collection. But memory leaks can still happen via closures or global references.");
