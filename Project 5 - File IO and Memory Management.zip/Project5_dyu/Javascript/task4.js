/*
 * Daniel Yu
 * April 11, 2025 
 * Since Node.js is being used, the 'fs' module can
 * be demonstrated to read and write files.
 */
const fs = require("fs");

// Open the file to read using process.argv[2]
let fp1 = fs.openSync(process.argv[2], 'r');

// Read the file contents into a string
const text = fs.readFileSync(fp1, "utf8");

// Example word count output string
const output = "This is example output.\nYou can replace this with actual processing.";

// Open another file to write the result (process.argv[3])
let fp2 = fs.openSync(process.argv[3], 'w');

// Write to the second file
fs.writeFileSync(fp2, output);

// Close both files
fs.closeSync(fp1);
fs.closeSync(fp2);

/*
 * prompt-sync package is used here in order for the user
 * to input a string — to retrieve user input
 * the sigint handles the ^C, when there is need to abort the text entry
 */
const prompt = require("prompt-sync")({ sigint: true });

/*
 * Displays a dialog box for a user to have the option in
 * entering a message. In other words input some text through the command prompt.
 */
const userString = prompt("Enter a string: ");
console.log("You entered:", userString);
