/*
Demonstrate how JavaScript is able to read from and write to a file.
Daniel Yu
task1.js
April 11, 2025
*/
/*
    JavaScript has built-in support for error handling, which 
    can be demonstrated by the 'try-catch' block:
    regarding how the block works, the code that may cause
    an error is placed in the 'try' block, while
    the 'catch' is implemented to handle the error. Therefore,
    if an error occurs in 'try,' JavaScript executes code 
    in the catch block

    JavaScript also provides an error object 'e', which prints out
    two properties of the error: error name and explains what the error is
*/

//the difference() function is being called, 
//when it does not exist, as a result, JavaScript would skip
//printing out the difference in print out the catch statement
//demonstrating the error
try
{
    let difference = subtract(20, 15);
    console.log(difference);
}
catch (e)
{
    /*
        Regarding the error object, six different values
        can be returned by the error name:
        - EvalError
        - RangeError
        - ReferenceError
        - SyntaxError
        - TypeError
        - URIError
    */

    //an example of a referenceError
    console.log({ name: e.name, message: e.message }); 
}

//Another example of a different type of exception from the error object
let a = 1;
try
{
    a.toLowerCase(); //cannot convert an integer to lower case
}
catch (e)
{
    //an example of a typeError
    console.log({ name: e.name, message: e.message }); 
}

//Last example of different type of exception from error object
try
{
    eval("alert('morning)");  //cannot convert an integer to lower case
}
catch (e)
{
    //an example of a syntaxError
    console.log({ name: e.name, message: e.message }); 
}

/*
    Other ways to handle errors are 'throw statements' which allows
    one to create a custom error - throws an exception
    'throw' can be used in the try-catch block, as well
*/

const num = 2;
throw num /0; //an exception should be generated, since it results in an undefined value



