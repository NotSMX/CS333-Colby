/*
 * Daniel Yu
 * April 11, 2025 
 * Garbage Sweep
 */

function allocateMemory() {
    // Allocate lots of short-lived objects
    const garbage = [];
    for (let i = 0; i < 1000; i++) {
        garbage.push({ index: i, text: "Some temporary data " + i });
    }
    return garbage;
}

function measureTimings(iterations = 1000) {
    const timings = [];
    const spikes = [];

    for (let i = 0; i < iterations; i++) {
        const start = process.hrtime.bigint();

        // Run memory-heavy function
        allocateMemory();

        const end = process.hrtime.bigint();
        const duration = Number(end - start) / 1e6; // Convert to milliseconds
        timings.push(duration);
    }

    // Calculate average and standard deviation
    const avg = timings.reduce((a, b) => a + b, 0) / timings.length;
    const stdev = Math.sqrt(
        timings.reduce((sum, val) => sum + Math.pow(val - avg, 2), 0) / timings.length
    );

    console.log(`Average duration: ${avg.toFixed(2)} ms`);
    console.log(`Standard deviation: ${stdev.toFixed(2)} ms`);
    console.log(`Spikes above 3 standard deviations:`);

    for (let i = 0; i < timings.length; i++) {
        if (timings[i] > avg + 3 * stdev) {
            console.log(`Iteration ${i} took ${timings[i].toFixed(2)} ms ⬅️ possible GC`);
            spikes.push(i);
        }
    }

    return spikes;
}

measureTimings();
