# CS333 - Project 5 - README
### Daniel Yu
### 4/10/2025

***Google Sites Report: https://sites.google.com/colby.edu/dans-cs333/home?authuser=1 ***

## Directory Layout:
```
├── C
│   ├── a.txt
│   ├── detect_garbage.c
│   ├── extension
│   ├── extension1.c
│   ├── malloc_timer.c
│   ├── task1.c
│   ├── task2.c
│   ├── task3.c
│   ├── wctest.txt
│   └── wordcounter.c
├── C++
│   ├── task1.cpp
│   ├── task1_2.cpp
│   ├── task2.cpp
│   ├── task3.cpp
│   ├── task4.cpp
│   ├── testfile.txt
│   └── wctest.txt
├── Java
│   ├── GCTest.class
│   └── GCTest.java
├── Javascript
│   ├── task1.js
│   ├── task2.js
│   ├── task3.js
│   ├── task4.js
│   ├── task5.js
│   └── wctest.txt
├── README.md
└── images
    ├── ctask1.png
    ├── ctask1_2.png
    ├── ctask1_3.png
    ├── ctask2.png
    ├── ctask3.png
    └── ctask4.png
```
## OS and C compiler
OS: Microsoft Windows Version 24H2 (OS Build 26100.2894)
C compiler: gcc (Ubuntu 13.3.0-6ubuntu2~24.04) 13.3.0

## Part I 
### Task 1
**Compile:** $ gcc -o task1 task1.c | $ gcc -o task2 task2.c | $ gcc -o task3 task3.c

**Run:** $ ./task1 | $ ./task2 | $ ./task3

**Output:**
![Screenshot of task 1's ctrl-c's output](images/ctask1.png)
![Screenshot of task 1's SIGFPE's output](images/ctask1_2.png)
![Screenshot of task 1's SIGSEGV's output](images/ctask1_3.png)

### Task 2
**Compile:** $ gcc -o wordcounter wordcounter.c

**Run:** $ ./wordcounter wctest.txt

**Q.b.** How Each Requirement Is Met:
a. Case-insensitive:
Handled by to_lowercase() before inserting the word.

b. Ignores punctuation:
Handled by clean_word() which filters only alphabetic characters.

c. Filename from command line:
Checked using argc and opened via fopen(argv[1], "r").

d. Top 20 frequencies printed in order:
Word list is stored in a linked list, copied to an array, sorted using qsort, and the top 20 printed.

**Output:**
![Screenshot of outputs](images/ctask2.png)

### Task 3
**Compile:** $ gcc -o malloc_timer malloc_timer.c

**Run:** $ ./malloc_timer

**Output:**
![Chart for correlation between int amount and average time per malloc](images/ctask3.png)

**Q.b.** From the results, we observed that the time it takes to allocate memory increased with the size of the allocation, though not linearly. For example, the average time for allocating 100 ints was approximately 0.5 µs, while allocating 10,000 ints took about 2.70 µs, and allocating 1,000,000 ints took 5.95 µs. This shows that the time does increase with the size, but the growth is sub-linear, likely due to internal optimizations in the memory allocator.

**Q.c.** Further analysis comparing allocating a large block versus multiple smaller chunks revealed that allocating one large block of memory was much more efficient than allocating many smaller chunks of equivalent total size. Allocating 10,000,000 ints as a single block took approximately 0 µs(???), while allocating 100,000 blocks of 100 ints (totaling the same memory size) took about 11,000 µs. This significant increase in time when allocating many small chunks is due to the overhead associated with each malloc call, indicating that fewer, larger allocations are much more efficient than many smaller ones.

### Task 4
**Compile:** $ gcc -o detect_garbage detect_garbage.c

**Run:** $ ./detect_garbage

**Output:**
![Screenshot of Drawing of Example](images/ctask4.png)

**Q.b.** This test case demonstrates a subtle memory leak that can't be collected by reference counting alone. We simulate four heap allocations and three stack variables (x, y, and z). After setting up references between them, we introduce a cycle between two heap chunks (dChunk and zChunk) and then nullify the reference to z from the stack. Even though dChunk and zChunk point to each other, they become unreachable from the stack and should be collected as garbage. This test effectively showcases the importance of using mark-and-sweep garbage collection rather than simple reference counting.

## Part II
### Task 1
**Compile:** $ g++ -o task1 task1.cpp | $ g++ -o task1_2 task1_2.cpp

**Run:** $ ./task1_2

**Output:** Please see on Google Site: https://sites.google.com/colby.edu/dans-cs333/project-5-c?authuser=1

### Task 2
**Compile:** $ g++ -o task2 task2.cpp

**Run:** $ ./task2

**Output:** Please see on Google Site: https://sites.google.com/colby.edu/dans-cs333/project-5-c?authuser=1

### Task 3
**Compile:** $ g++ -o task3 task3.cpp

**Run:** $ ./task3 wctest.txt

**Output:** Please see on Google Site: https://sites.google.com/colby.edu/dans-cs333/project-5-c?authuser=1

### Task 4
**Compile:** $ g++ -o task4 task4.cpp

**Run:** $ ./task4

**Output:** Please see on Google Site: https://sites.google.com/colby.edu/dans-cs333/project-5-c?authuser=1

### Task 5
**Compile:** $ javac GCTest.java

**Run:** $ java GCTest

**Output:** Please see on Google Site: https://sites.google.com/colby.edu/dans-cs333/project-5-c?authuser=1

## Extensions

### Extension 1
**Description**
Firstly, as always, I did all tasks in Part II for the second language I'm learning, Javascript.

**Run:** $ node task1.js | node task2.js | node task3.js wctest.txt | node task4.js | node task5.js

**Output:** Please see on Google Site: https://sites.google.com/colby.edu/dans-cs333/project-5-javascript?authuser=1

### Extension 2
**Description**
The memory management example for Javascript also has a functionally equivalent example in C, (task2.js) explicitly handling the kinds of information required for the memory management system of your chosen language.

**Output:** Please see on Google Site: https://sites.google.com/colby.edu/dans-cs333/project-5-javascript?authuser=1

### Extension 3
**Description**
I decided to make the word counter created in C more robust so that it was able to handle invalid command-line inputs and invalid files. In wordcounter.c, if the user does not input the correct number of arguments, then it will result in an exception. Additionally, if the files that are being inputted are nulls, then another exception will be demonstrated, which will tell the user that the file does not exist. 

**Compile:** $ gcc -o wordcounter wordcounter.c

**Run:** $ ./wordcounter wctest.txt

### Extension 4
**Description**
I looked up the code for malloc and free in glibc and explain how they work in your Google Sites report.

**Output:** Please see on Google Site: https://sites.google.com/colby.edu/dans-cs333/project-5-javascript?authuser=1

### Extension 5
**Description**
FInally, I implemented another data structure to support the word frequency task, which was a Binary Tree.

**Compile:** $ gcc -o extension extension1.c 

**Run:** $ ./extension wctest.txt a.txt

**Output:** Please see the file a.txt! It's exactly the same!