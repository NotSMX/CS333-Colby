/**
 * 
 * A word counter that is able to count the number of occurrences
 * of every word in a text file using a Binary Tree
 * 
 * extension1.c
 * Daniel Yu
 * April 13, 2025
 * 
 * 
 * How to Test:
 * gcc -o extension extension1.c 
 * ./extension wctest.txt a.txt
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

//create the struct of the treenodes
typedef struct TreeNode 
{
    char* word;
    int count;

    struct TreeNode* left;
    struct TreeNode* right;
} TreeNode;

//use to insert the words into the tree
void insert(TreeNode** root, char* word) 
{
    //To ignore the punctuation 
    int len = strlen(word);
    char new_word[len];
    int j = 0;
    for (int i = 0; i < len; i++) {
        if (!ispunct(word[i])) {
            new_word[j++] = tolower(word[i]);
        }
    }
    new_word[j] = '\0';

    //check if the root is null, if it is,
    //then this word is the first element being added to the 
    //tree
    if (*root == NULL) 
    {
        *root = (TreeNode*) malloc(sizeof(TreeNode));

        //uses to duplicate the string
        (*root)->word = strdup(new_word);

        //set the count to 1
        (*root)->count = 1;

        //set the left and right nodes to be NULL
        (*root)->left = NULL;
        (*root)->right = NULL;
    } 
    else 
    {
        //else, add the word depending on where it is located in the tree
        //and increment the count 
        int a = strcmp(new_word, (*root)->word);

        //check where the placement of the word is at in the tree
        if (a == 0) 
        {
            (*root)->count++;
        } else if (a < 0) {
            insert(&((*root)-> left), new_word);
        } else {
            insert(&((*root)-> right), new_word);
        }
    }
}

// Function to compare tree nodes based on their count
//an example of qsort
int compareNodes(const void* node1, const void* node2) 
{
    //helps to sortthe array based on the count of each
    //node such that the top 20 words can be printed out
    TreeNode* n1 = *(TreeNode**)node1;
    TreeNode* n2 = *(TreeNode**)node2;
    return n2->count - n1->count;
}

// Function to traverse the binary tree in-order and put all nodes into an array
void ArrayofNodes(TreeNode* node, TreeNode** nodes, int* index) {
    
    if (node == NULL) 
    {
        return;
    }

    //depending on where the node is located, the 
    //node will be added in the array on index
    ArrayofNodes(node->left, nodes, index);
    nodes[*index] = node;
    (*index)++;
    ArrayofNodes(node->right, nodes, index);
}


/*
To print the words in the tree
*/
void printTree(TreeNode* root, FILE *fp)
{
    TreeNode* nodes[10000]; // Maximum number of nodes
    int numNodes = 0;
    ArrayofNodes(root, nodes, &numNodes);
    qsort(nodes, numNodes, sizeof(TreeNode*), compareNodes);
    for (int i = 0; i < 20 && i < numNodes; i++) {
        fprintf(fp, "%10s \t %d\n", nodes[i]->word, nodes[i]->count);
}
}

int main(int argc, char*argv[])
{
    //declaration of variables
    TreeNode* root = NULL;
    FILE *fp1, *fp2;

    //open the files to get the input
    fp1 = fopen(argv[1], "r");

    //open the text that would contain the outputted text
    fp2 = fopen(argv[2], "w");

    char word[50];
    int i = 0;

    //a while loop used to go through each word in the file
    while (fscanf(fp1, "%49s", word) == 1) {
        // Convert the word to lowercase
        for (int i = 0; word[i] != '\0'; i++) {
            word[i] = tolower(word[i]);
        }
        
        // Add the word to the linked list
        insert(&root, word);
    }
    printTree(root, fp2);

    //close the files, and free the file pointers
    fclose(fp1);
    fclose(fp2);


    return 0;
}