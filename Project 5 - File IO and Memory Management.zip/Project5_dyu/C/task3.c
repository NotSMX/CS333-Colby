/**
 * Write a program that can handle a segmentation fault error. Your main function should set up a handler for the SIGSEGV signal 
 * then execute code that results in a segmentation fault (access illegal memory). Your handler should print something appropriate and exit.
 * Daniel Yu
 * April 10, 2025
 */

#include <stdio.h>
#include <signal.h>
#include <stdlib.h>

// Signal handler for segmentation faults (SIGSEGV)
void handle_sigsegv(int sig) {
    printf("Caught SIGSEGV: Segmentation fault occurred.\n");
    printf("Exiting program safely after illegal memory access.\n");
    exit(EXIT_FAILURE);
}

int main() {
    // Set up the signal handler for SIGSEGV
    signal(SIGSEGV, handle_sigsegv);

    printf("About to perform illegal memory access...\n");

    // Deliberately cause a segmentation fault
    int *ptr = NULL;
    *ptr = 42;  // This will trigger SIGSEGV

    // This line will never be reached
    printf("This line will not execute.\n");

    return 0;
}
