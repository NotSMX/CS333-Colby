/**
 * Write a program that can respond to a ctrl-C (interrupt). Your main function should use the signal function to set up a handler for the 
 * SIGINT signal and then enter an infinite loop. Your handler function just needs to print out a message (e.g. "Interrupted!") and then call exit();
 * Daniel Yu
 * April 10, 2025
 */

#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <unistd.h>

void handle_sigint(int sig) {
    printf("\nInterrupted! (SIGINT received)\n");
    exit(0);
}

int main() {
    signal(SIGINT, handle_sigint);
    printf("Running... Press Ctrl+C to interrupt.\n");

    while (1) {
        sleep(1); // Simulate work
    }

    return 0;
}
