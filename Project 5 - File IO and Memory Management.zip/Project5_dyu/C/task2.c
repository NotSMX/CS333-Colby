/**
 * Write a program that can handle a floating point exception. Your main function should use the signal function to set up a handler for the SIGFPE signal then do 
 * something inappropriate with floating point values, such as dividing by zero. See if you can continue the program's execution after the exception takes place.
 * Daniel Yu
 * April 10, 2025
 */

 #include <stdio.h>
 #include <signal.h>
 #include <stdlib.h>
 #include <setjmp.h>
 
 // Buffer to store program state for recovery after the signal
 jmp_buf env;
 
 // Signal handler for SIGFPE (floating point exception)
 void handle_sigfpe(int sig) {
     printf("Caught SIGFPE: Floating point exception occurred.\n");
 
     // Restore the program state to a safe recovery point
     // This avoids crashing and lets the program continue
     longjmp(env, 1);
 }
 
 int main() {
     // Set up SIGFPE signal handler to call our custom handler
     signal(SIGFPE, handle_sigfpe);
 
     // Save current program state in case of exception
     // setjmp returns 0 initially, and non-zero after longjmp
     if (setjmp(env) == 0) {
         // First time through, before exception occurs
         printf("Attempting risky floating-point operation...\n");
 
         // Perform division by zero, which triggers SIGFPE
         int a = 5;
         int b = 0;
         int c = a / b;  // Unsafe: division by zero
 
         // This line is *not* reached if SIGFPE occurs
         printf("Result: %d\n", c);
     } else {
         // Control jumps here *after* SIGFPE is caught and longjmp is called
         printf("Recovered from floating point exception. Program continues.\n");
     }
 
     // This line shows that program continues normally after exception is handled
     printf("Program completed safely.\n");
 
     return 0;
 }
 
