/**
 * 
 * Estimating the time cost of memory management
 * 
 * Daniel Yu
 * April 13, 2025
 *
*/

#include <stdio.h>
#include <stdlib.h>
#include <sys/timeb.h>

#define NUM_RUNS 10000

void run_test(size_t num_ints, const char* label) {
    int **ptrs = malloc(NUM_RUNS * sizeof(int*));
    struct timeb start, end;

    // Warm-up malloc (skip timing)
    ptrs[0] = malloc(num_ints * sizeof(int));

    ftime(&start);
    for (int i = 1; i < NUM_RUNS; i++) {
        ptrs[i] = malloc(num_ints * sizeof(int));
    }
    ftime(&end);

    // Calculate elapsed time in milliseconds
    int elapsed_ms = (int)(1000 * (end.time - start.time) + (end.millitm - start.millitm));
    double avg_per_alloc_us = (elapsed_ms * 1000.0) / (NUM_RUNS - 1); // microseconds

    printf("%s - Size: %zu bytes - Avg time per malloc: %.3f µs\n",
           label, num_ints * sizeof(int), avg_per_alloc_us);

    for (int i = 0; i < NUM_RUNS; i++) {
        free(ptrs[i]);
    }
    free(ptrs);
}

void compare_chunked_vs_bulk(size_t total_ints, size_t chunk_size) {
    struct timeb start, end;

    size_t total_bytes = total_ints * sizeof(int);
    size_t chunk_bytes = chunk_size * sizeof(int);
    size_t num_chunks = total_ints / chunk_size;

    // === Bulk Allocation ===
    ftime(&start);
    int *bulk_ptr = malloc(total_bytes);
    ftime(&end);
    double bulk_time_us = (1000 * (end.time - start.time) + (end.millitm - start.millitm)) * 1000.0;

    free(bulk_ptr);

    // === Chunked Allocation ===
    int **chunks = malloc(num_chunks * sizeof(int*));

    ftime(&start);
    for (size_t i = 0; i < num_chunks; i++) {
        chunks[i] = malloc(chunk_bytes);
    }
    ftime(&end);
    double chunked_time_us = (1000 * (end.time - start.time) + (end.millitm - start.millitm)) * 1000.0;

    for (size_t i = 0; i < num_chunks; i++) {
        free(chunks[i]);
    }
    free(chunks);

    printf("\n== Chunked vs Bulk Allocation Comparison ==\n");
    printf("Total memory: %zu ints (%zu bytes)\n", total_ints, total_bytes);
    printf("Chunk size:   %zu ints (%zu bytes)\n", chunk_size, chunk_bytes);
    printf("Bulk allocation time:    %.3f µs\n", bulk_time_us);
    printf("Chunked allocation time: %.3f µs\n", chunked_time_us);
}


int main() {
    run_test(100, "Small");
    run_test(10000, "Medium");
    run_test(1000000, "Large");

    // Compare allocating 1,000,000 ints in chunks of 100 vs all at once
    compare_chunked_vs_bulk(10000000, 100);

    return 0;
}
