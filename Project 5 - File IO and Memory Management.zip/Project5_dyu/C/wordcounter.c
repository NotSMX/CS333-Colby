/**
 * 
 * A word counter that is able to count the number of occurrences
 * of every word in a text file
 * 
 * task1.c
 * Daniel Yu
 * April 10, 2025
 * 
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#define MAX_WORD_LEN 100

// Linked list node for storing a word and its frequency
typedef struct Node {
    char *word;
    int count;
    struct Node *next;
} Node;

// Convert string to lowercase
void to_lowercase(char *str) {
    while (*str) {
        *str = tolower(*str);
        str++;
    }
}

// Remove punctuation from a word (in-place)
void clean_word(char *word) {
    int i = 0, j = 0;
    while (word[i]) {
        if (isalpha(word[i])) {
            word[j++] = word[i];
        }
        i++;
    }
    word[j] = '\0';
}

// Insert or update a word in the linked list
void insert_word(Node **head, const char *word) {
    Node *curr = *head;

    // Check if word exists
    while (curr) {
        if (strcmp(curr->word, word) == 0) {
            curr->count++;
            return;
        }
        curr = curr->next;
    }

    // Word not found, add new node
    Node *new_node = malloc(sizeof(Node));
    new_node->word = strdup(word);
    new_node->count = 1;
    new_node->next = *head;
    *head = new_node;
}

// Count the number of nodes in the list
int list_length(Node *head) {
    int count = 0;
    while (head) {
        count++;
        head = head->next;
    }
    return count;
}

// Copy linked list to array for sorting
Node** list_to_array(Node *head) {
    int size = list_length(head);
    Node **arr = malloc(size * sizeof(Node*));
    int i = 0;
    while (head) {
        arr[i++] = head;
        head = head->next;
    }
    return arr;
}

// Sort the array of nodes by frequency (descending)
int compare(const void *a, const void *b) {
    Node *na = *(Node**)a;
    Node *nb = *(Node**)b;
    return nb->count - na->count;
}

int main(int argc, char *argv[]) {
    if (argc < 2) {
        fprintf(stderr, "Usage: %s <filename>\n", argv[0]);
        return 1;
    }

    FILE *file = fopen(argv[1], "r");
    if (!file) {
        perror("Error opening file");
        return 1;
    }

    Node *head = NULL;
    char word[MAX_WORD_LEN];

    // Read words from file
    while (fscanf(file, "%s", word) == 1) {
        clean_word(word);
        to_lowercase(word);
        if (strlen(word) > 0) {
            insert_word(&head, word);
        }
    }

    fclose(file);

    // Convert list to array and sort
    int size = list_length(head);
    Node **arr = list_to_array(head);
    qsort(arr, size, sizeof(Node*), compare);

    // Print top 20 words
    printf("\nTop 20 Words:\n");
    int limit = size < 20 ? size : 20;
    for (int i = 0; i < limit; i++) {
        printf("%7s\t%d\n", arr[i]->word, arr[i]->count);
    }

    // Free memory
    for (int i = 0; i < size; i++) {
        free(arr[i]->word);
        free(arr[i]);
    }
    free(arr);

    return 0;
}
