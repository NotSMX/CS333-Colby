/**
 * C++ Error Handling
 * Daniel Yu
 * April 10, 2025
 */
#include <iostream>
using namespace std;

int divide(int a, int b) {
    if (b == 0)
        throw runtime_error("Division by zero");
    return a / b;
}

int main() {
    try {
        cout << divide(10, 0) << endl;
    } catch (runtime_error &e) {
        cout << "Caught an exception: " << e.what() << endl;
    }
}
