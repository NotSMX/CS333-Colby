 /**
 * File Reading Techniques
 * Daniel Yu
 * April 10, 2025
 */
#include <iostream>
#include <fstream>
#include <string>

using namespace std;

void writeFile(const string& filename) {
    ofstream file(filename);
    if (file.is_open()) {
        file << "This is a line written to a file.\n";
        // file.close();
    }
}

void readFile(const string& filename) {
    ifstream file(filename);
    string line;
    if (file.is_open()) {
        while (getline(file, line)) {
            cout << line << endl;
        }
        file.close();
    } else {
        cerr << "Unable to open file." << endl;
    }
}

int main() {
    string filename = "wctest.txt";
    writeFile(filename);
    readFile(filename);
    string name;
    cout << "Enter your name: ";
    cin >> name;
    cout << "Hello, " << name << "!\n";
    return 0;
}
