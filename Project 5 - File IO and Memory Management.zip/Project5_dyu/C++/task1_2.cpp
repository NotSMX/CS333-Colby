/**
 * C++ Error Handling
 * Daniel Yu
 * April 10, 2025
 */
#include <iostream>
#include <fstream>
#include <stdexcept>
using namespace std;

void openFile(const string &filename) {
    ifstream file(filename);
    if (!file)
        throw runtime_error("Cannot open file: " + filename);
}

int main() {
    try {
        openFile("doesnotexist.txt");
    } catch (const runtime_error &e) {
        cerr << e.what() << endl;
    }
}
