 /**
 * Word Frequency Counter
 * Daniel Yu
 * April 10, 2025
 */
#include <iostream>
#include <fstream>
#include <string>
#include <unordered_map>
#include <queue>
#include <algorithm>
#include <cctype>

using namespace std;

// Comparator to sort by frequency in descending order
struct cmp {
    bool operator()(pair<string, int> &a, pair<string, int> &b) {
        return a.second < b.second;
    }
};

int main(int argc, char* argv[]) {
    if (argc < 2) {
        cout << "Usage: " << argv[0] << " <filename>\n";
        return 1;
    }

    unordered_map<string, int> wordCount;
    ifstream file(argv[1]);
    if (!file) {
        cout << "File cannot be opened, please check for .txt files\n";
        return 1;
    }

    string word;
    while (file >> word) {
        // Convert to lowercase
        transform(word.begin(), word.end(), word.begin(), [](unsigned char c) {
            return tolower(c);
        });

        // Remove punctuation
        word.erase(remove_if(word.begin(), word.end(), [](unsigned char c) {
            return ispunct(c);
        }), word.end());

        if (word.length() > 0) {
            wordCount[word]++;
        }
    }

    // Priority queue for top frequency words
    priority_queue<pair<string, int>, vector<pair<string, int>>, cmp> topWords;
    for (auto &pair : wordCount) {
        topWords.push(pair);
    }

    // Print top 20 words
    cout << "Top 20 words:\n";
    for (int i = 0; i < 20 && !topWords.empty(); i++) {
        pair<string, int> wordPair = topWords.top();
        cout << wordPair.first << ": " << wordPair.second << endl;
        topWords.pop();
    }

    return 0;
}