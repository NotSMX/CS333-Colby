/**
 * Memory Management in C++
 * Daniel Yu
 * April 10, 2025
 */
#include <iostream>
#include <vector>
using namespace std;

void manualMemoryExample() {
    int* a = new int(5); // explicit allocation
    cout << "Allocated int: " << *a << endl;
    delete a; // explicit deallocation
}

void automaticMemoryExample() {
    vector<int> nums = {1, 2, 3, 4}; // allocated automatically
    for (int n : nums) cout << n << " ";
    cout << endl;
} 

int main() {
    manualMemoryExample();
    automaticMemoryExample();
    return 0;
}
