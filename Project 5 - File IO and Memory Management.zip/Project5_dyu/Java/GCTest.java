/* 
 * Since C++ doesn't have automatic memory management, here is a test with Java
 * Daniel Yu
 * April 13, 2025
 */
public class GCTest {

    static long allocateMemory() {
        long start = System.nanoTime();

        // Allocate and discard a large array to stress memory
        for (int i = 0; i < 1000; i++) {
            int[] temp = new int[1_000_000];
        }

        return System.nanoTime() - start;
    }

    public static void main(String[] args) {
        final int iterations = 100;
        long[] durations = new long[iterations];
        long total = 0;

        System.out.println("Timing memory allocation...");

        for (int i = 0; i < iterations; i++) {
            durations[i] = allocateMemory();
            total += durations[i];
            System.out.printf("Iteration %d: %d ns\n", i, durations[i]);
        }

        long average = total / iterations;
        System.out.println("\nAverage duration: " + average + " ns");

        System.out.println("\nLikely GC events (duration > 2x average):");
        for (int i = 0; i < iterations; i++) {
            if (durations[i] > average * 2) {
                System.out.printf("  Iteration %d: %d ns\n", i, durations[i]);
            }
        }
    }
}
