/*
    Extended test file for LinkedList implementation with multiple data types
    Daniel Yu
    task2test.js
    March 22, 2025
*/

const LinkedList = require("./task2");

// Comparison function for integers
const compFunc = (a, b) => (a === b ? 0 : a < b ? -1 : 1);

// Comparison function for strings
const compFuncString = (a, b) => a.localeCompare(b);

// Free function (dummy function in JavaScript)
const freeFunc = (data) => console.log(`Freeing: ${data}`);

// Map function for integers (squares numbers)
const mapFunc = (data) => console.log(`Squared: ${data * data}`);

// Map function for strings (converts to uppercase)
const mapFuncString = (data) => console.log(`Uppercase: ${data.toUpperCase()}`);

console.log("\n===== Testing LinkedList<int> =====");
const intList = LinkedList.ll_create();

intList.ll_push(10);
intList.ll_push(20);
intList.ll_push(30);
console.log("After pushing elements:");
intList.display();

console.log("Popped:", intList.ll_pop());
intList.display();

intList.ll_append(40);
intList.ll_append(50);
console.log("After appending elements:");
intList.display();

console.log("Removed:", intList.ll_remove(40, compFunc));
intList.display();

console.log("Finding 50:", intList.ll_find(50, compFunc) ? "Found" : "Not Found");
console.log("Finding 100:", intList.ll_find(100, compFunc) ? "Found" : "Not Found");

console.log("List size:", intList.ll_size());

console.log("Applying map function:");
intList.ll_map(mapFunc);

intList.ll_clear(freeFunc);
console.log("After clearing the list:");
intList.display();
console.log("List size:", intList.ll_size());

console.log("\n===== Testing LinkedList<string> =====");
const strList = LinkedList.ll_create();

strList.ll_push("apple");
strList.ll_push("banana");
strList.ll_push("cherry");
console.log("After pushing elements:");
strList.display();

console.log("Popped:", strList.ll_pop());
strList.display();

strList.ll_append("date");
strList.ll_append("elderberry");
console.log("After appending elements:");
strList.display();

console.log("Removed:", strList.ll_remove("banana", compFuncString));
strList.display();

console.log("Finding 'elderberry':", strList.ll_find("elderberry", compFuncString) ? "Found" : "Not Found");
console.log("Finding 'grape':", strList.ll_find("grape", compFuncString) ? "Found" : "Not Found");

console.log("List size:", strList.ll_size());

console.log("Applying map function:");
strList.ll_map(mapFuncString);

strList.ll_clear(freeFunc);
console.log("After clearing the list:");
strList.display();
console.log("List size:", strList.ll_size());
