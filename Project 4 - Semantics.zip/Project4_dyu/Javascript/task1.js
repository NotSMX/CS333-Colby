/*
A program that implements a sort algorithm that can be used for any type 
and can be used to obtain any desired order. In this case, the sorting 
algorithm that will be demontrated is insertion sort. 

Daniel Yu
task1.js
March 22, 2024
*/

/*
Insertion sort uses the recursion technique. 
The purpose of the sort is to compare the elements
from the unsorted portion one by one and insert them
into the sorted portion in the correct order. Since the array
that will be demonstrated will be unsorted and sorted. 
*/
function insertionSort(arr, order = '')
{
    /*
    Comparing the second element of the array 
    with the first element assuming the first element is the sorted portion. 
    The elements will swap if second element is smaller than the first element.
    */
    for (let x = 1; x < arr.length; x++)
    {
        /*
        Comparing the first element with 
        each element of the unsorted portion. Therefore, checking that
        if the element from the unsorted portion is smaller than it, 
        a swap should be demonstrated.
        */
        for (let y = x - 1; y > -1; y--)
        {
            //check what order is being asked
            if (order == 'ascending')
            {
                //value comparison in terms of ascending order
                if(arr[y + 1] < arr[y])
                {
                    /*
                    this line compares the next index in the array (specifically the
                    sorted portion)
                    recurisvely with the value of the current index that is 
                    being worked on. A swap should be demonstrated when a value that
                    has not been sorted is smaller. This swap will continue to occur
                    until the order is demonstrated correctly. 
                    */
                    [arr[y+1],arr[y]] = [arr[y],arr[y + 1]];
                }   
            }
            else
            {
                //value comparison in terms of descending order
                //checking if the next element is bigger than the other
                if(arr[y + 1] > arr[y])
                {
                    /*
                    this line compares the next index in the array (specifically the
                    sorted portion)
                    recurisvely with the value of the current index that is 
                    being worked on. A swap should be demonstrated when a value that
                    has not been sorted is greater. This swap will continue to occur
                    until the order is demonstrated correctly. 
                    */
                    [arr[y+1],arr[y]] = [arr[y],arr[y + 1]];
                }   
            }

        }
    }
   return arr;
}

/*
testing the program! there are only two orders: ascending and descending
*/
console.log("Integer Types");
console.log(insertionSort([12, 3, 10, 82, 8, 5], 'descending'));
console.log("Char Types");
console.log(insertionSort(['A', 'D', 'B', 'E', 'H', 'C'], 'ascending'));
console.log("String Types");
console.log(insertionSort(["apple", "durian", "berries", "elderberry", "honeydew", "cantoloupe"], 'descending'));



