// Node class
class Node {
    constructor(data) {
        this.data = data;
        this.next = null;
    }
}

// LinkedList class
class LinkedList {
    constructor() {
        this.head = null;
        this.size = 0;
    }

    // ll_create() - Creates a new LinkedList
    static ll_create() {
        return new LinkedList();
    }

    // ll_push() - Adds a node to the front of the list
    ll_push(data) {
        const newNode = new Node(data);
        newNode.next = this.head;
        this.head = newNode;
        this.size++;
    }

    // ll_pop() - Removes the front node and returns its data
    ll_pop() {
        if (!this.head) return null;
        const data = this.head.data;
        this.head = this.head.next;
        this.size--;
        return data;
    }

    // ll_append() - Adds a node to the end of the list
    ll_append(data) {
        const newNode = new Node(data);
        if (!this.head) {
            this.head = newNode;
        } else {
            let temp = this.head;
            while (temp.next) {
                temp = temp.next;
            }
            temp.next = newNode;
        }
        this.size++;
    }

    // ll_remove() - Removes the first node matching target using compfunc
    ll_remove(target, compfunc) {
        if (!this.head) return null;

        if (compfunc(this.head.data, target) === 0) {
            return this.ll_pop(); // Remove head if it matches
        }

        let prev = this.head;
        let curr = this.head.next;

        while (curr) {
            if (compfunc(curr.data, target) === 0) {
                prev.next = curr.next;
                this.size--;
                return curr.data;
            }
            prev = curr;
            curr = curr.next;
        }
        return null; // Target not found
    }

    // ll_find() - Finds the first node matching target using compfunc
    ll_find(target, compfunc) {
        let temp = this.head;
        while (temp) {
            if (compfunc(temp.data, target) === 0) {
                return temp.data;
            }
            temp = temp.next;
        }
        return null; // Not found
    }

    // ll_size() - Returns the size of the list
    ll_size() {
        return this.size;
    }

    // ll_clear() - Clears the list and frees data using freefunc
    ll_clear(freefunc) {
        let temp = this.head;
        while (temp) {
            freefunc(temp.data);
            temp = temp.next;
        }
        this.head = null;
        this.size = 0;
    }

    // ll_map() - Traverses the list and applies mapfunc to each node's data
    ll_map(mapfunc) {
        let temp = this.head;
        while (temp) {
            mapfunc(temp.data);
            temp = temp.next;
        }
    }

    // Utility: Display list contents
    display() {
        let temp = this.head;
        let output = "";
        while (temp) {
            output += temp.data + " -> ";
            temp = temp.next;
        }
        console.log(output + "NULL");
    }
}

// Exporting the LinkedList class
module.exports = LinkedList;
