/*
A program that demonstrates memory behavior in JavaScript,  
focusing on reference-based assignment, automatic memory management,  
and heap allocation for objects and arrays. Unlike C++, JavaScript  
does not have explicit memory operators like `&` or `*`, but uses  
references to manage object memory dynamically.  

Daniel Yu  
MemoryTest.js  
March 22, 2025 
*/

// Demonstrating JavaScript memory behavior

let obj1 = { value: 10 };
let obj2 = obj1; // Reference copy

console.log("Original value:", obj1.value);
obj2.value = 20;
console.log("Modified value via obj2:", obj1.value); // Reference behavior

// JavaScript automatically manages memory, no explicit deallocation needed
let arr = new Array(5); // Heap allocation example
console.log("Array length:", arr.length);
