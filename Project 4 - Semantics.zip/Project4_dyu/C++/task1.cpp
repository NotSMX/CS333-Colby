/*
    This template-based QuickSort allows sorting any data type and provides an option for ascending or descending order.
    Daniel Yu
    task1.cpp
    March 22, 2025
 * 
*/

#include <iostream>
#include <vector>

// Generic QuickSort function
template <typename T>
void quickSort(std::vector<T>& arr, int left, int right, bool ascending = true) {
    if (left >= right) return;

    T pivot = arr[right];
    int partitionIndex = left;

    for (int i = left; i < right; i++) {
        if ((ascending && arr[i] < pivot) || (!ascending && arr[i] > pivot)) {
            std::swap(arr[i], arr[partitionIndex]);
            partitionIndex++;
        }
    }
    std::swap(arr[partitionIndex], arr[right]);

    quickSort(arr, left, partitionIndex - 1, ascending);
    quickSort(arr, partitionIndex + 1, right, ascending);
}

// Function to print array
template <typename T>
void printArray(const std::vector<T>& arr) {
    for (const T& elem : arr) {
        std::cout << elem << " ";
    }
    std::cout << std::endl;
}

// Test program for sorting algorithm
int main() {
    std::vector<int> intArr = {5, 2, 9, 1, 5, 6};
    std::vector<std::string> strArr = {"apple", "orange", "banana", "grape"};

    std::cout << "Original integer array: ";
    printArray(intArr);
    quickSort(intArr, 0, intArr.size() - 1);
    std::cout << "Sorted integer array (ascending): ";
    printArray(intArr);

    std::cout << "Original string array: ";
    printArray(strArr);
    quickSort(strArr, 0, strArr.size() - 1, false);
    std::cout << "Sorted string array (descending): ";
    printArray(strArr);

    return 0;
}
