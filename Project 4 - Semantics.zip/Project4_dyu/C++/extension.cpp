/*
A program that demonstrates the use of memory operators in C++,  
including address-of (`&`), dereference (`*`), and dynamic memory  
allocation (`new` and `delete`). It explores how pointers work  
and compares stack and heap memory allocation.  

Daniel Yu  
MemoryTest.cpp  
March 22, 2025  
*/

#include <iostream>

// Demonstrating C++ memory operators
int main() {
    int x = 10;
    int* ptr = &x; // Pointer stores address of x

    std::cout << "Address of x: " << &x << std::endl;
    std::cout << "Value stored in ptr (address of x): " << ptr << std::endl;
    std::cout << "Dereferencing ptr: " << *ptr << std::endl;

    // Dynamic memory allocation
    int* heapVar = new int(50);
    std::cout << "Dynamically allocated value: " << *heapVar << std::endl;

    delete heapVar; // Free memory
    return 0;
}
