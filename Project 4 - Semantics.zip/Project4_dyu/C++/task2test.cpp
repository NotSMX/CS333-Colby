/*
    A test file like the C test file that demonstrates creating linked lists to store two different types of data.
    Daniel Yu
    task2test.cpp
    March 22, 2025
 * 
*/

#include <iostream>
#include "task2.cpp" // Including the LinkedList implementation

// Comparison function for integers
int compFunc(int a, int b) {
    return (a == b) ? 0 : (a < b ? -1 : 1);
}

// Comparison function for strings
int compFuncString(std::string a, std::string b) {
    return a.compare(b);
}

// Free function (dummy function in C++)
void freeFunc(int data) {
    std::cout << "Freeing: " << data << std::endl;
}

void freeFuncString(std::string data) {
    std::cout << "Freeing: " << data << std::endl;
}

// Map function for integers (squares numbers)
void mapFunc(int data) {
    std::cout << "Squared: " << data * data << std::endl;
}

// Map function for strings (converts to uppercase)
void mapFuncString(std::string data) {
    std::string upperCaseData;
    for (char c : data) {
        upperCaseData += std::toupper(c);
    }
    std::cout << "Uppercase: " << upperCaseData << std::endl;
}

int main() {
    // **************************
    // Testing LinkedList<int>
    // **************************
    std::cout << "\n===== Testing LinkedList<int> =====" << std::endl;
    LinkedList<int>* intList = LinkedList<int>::ll_create();

    intList->ll_push(10);
    intList->ll_push(20);
    intList->ll_push(30);
    std::cout << "After pushing elements:" << std::endl;
    intList->display();

    std::cout << "Popped: " << intList->ll_pop() << std::endl;
    intList->display();

    intList->ll_append(40);
    intList->ll_append(50);
    std::cout << "After appending elements:" << std::endl;
    intList->display();

    std::cout << "Removed: " << intList->ll_remove(40, compFunc) << std::endl;
    intList->display();

    std::cout << "Finding 50: " << (intList->ll_find(50, compFunc) ? "Found" : "Not Found") << std::endl;
    std::cout << "Finding 100: " << (intList->ll_find(100, compFunc) ? "Found" : "Not Found") << std::endl;

    std::cout << "List size: " << intList->ll_size() << std::endl;

    std::cout << "Applying map function:" << std::endl;
    intList->ll_map(mapFunc);

    intList->ll_clear(freeFunc);
    std::cout << "After clearing the list:" << std::endl;
    intList->display();
    std::cout << "List size: " << intList->ll_size() << std::endl;

    delete intList;

    // **************************
    // Testing LinkedList<std::string>
    // **************************
    std::cout << "\n===== Testing LinkedList<std::string> =====" << std::endl;
    LinkedList<std::string>* strList = LinkedList<std::string>::ll_create();

    strList->ll_push("apple");
    strList->ll_push("banana");
    strList->ll_push("cherry");
    std::cout << "After pushing elements:" << std::endl;
    strList->display();

    std::cout << "Popped: " << strList->ll_pop() << std::endl;
    strList->display();

    strList->ll_append("date");
    strList->ll_append("elderberry");
    std::cout << "After appending elements:" << std::endl;
    strList->display();

    std::cout << "Removed: " << strList->ll_remove("banana", compFuncString) << std::endl;
    strList->display();

    std::cout << "Finding 'elderberry': " << (strList->ll_find("elderberry", compFuncString) ? "Found" : "Not Found") << std::endl;
    std::cout << "Finding 'grape': " << (strList->ll_find("grape", compFuncString) ? "Found" : "Not Found") << std::endl;

    std::cout << "List size: " << strList->ll_size() << std::endl;

    std::cout << "Applying map function:" << std::endl;
    strList->ll_map(mapFuncString);

    strList->ll_clear(freeFuncString);
    std::cout << "After clearing the list:" << std::endl;
    strList->display();
    std::cout << "List size: " << strList->ll_size() << std::endl;

    delete strList;

    return 0;
}