/*
    A generic linked list with functions to insert, remove, search, and display elements.
    Daniel Yu
    task2.cpp
    March 22, 2025
 * 
*/

#include <iostream>

// Node structure using templates
template <typename T>
class Node {
public:
    T data;
    Node* next;

    Node(T value) : data(value), next(nullptr) {}
};

// LinkedList class using templates
template <typename T>
class LinkedList {
private:
    Node<T>* head;
    int size;

public:
    // Constructor
    LinkedList() : head(nullptr), size(0) {}

    // ll_create() - Creates a new LinkedList
    static LinkedList<T>* ll_create() {
        return new LinkedList<T>();
    }

    // ll_push() - Adds a node to the front of the list
    void ll_push(T data) {
        Node<T>* newNode = new Node<T>(data);
        newNode->next = head;
        head = newNode;
        size++;
    }

    // ll_pop() - Removes the front node and returns its data
    T ll_pop() {
        if (!head) throw std::runtime_error("List is empty!");
        Node<T>* temp = head;
        T data = temp->data;
        head = head->next;
        delete temp;
        size--;
        return data;
    }

    // ll_append() - Adds a node to the end of the list
    void ll_append(T data) {
        Node<T>* newNode = new Node<T>(data);
        if (!head) {
            head = newNode;
        } else {
            Node<T>* temp = head;
            while (temp->next) {
                temp = temp->next;
            }
            temp->next = newNode;
        }
        size++;
    }

    // ll_remove() - Removes the first node matching target using compfunc
    T ll_remove(T target, int (*compfunc)(T, T)) {
        if (!head) throw std::runtime_error("List is empty!");

        if (compfunc(head->data, target) == 0) {
            return ll_pop(); // Remove head if it matches
        }

        Node<T>* prev = head;
        Node<T>* curr = head->next;

        while (curr) {
            if (compfunc(curr->data, target) == 0) {
                prev->next = curr->next;
                T data = curr->data;
                delete curr;
                size--;
                return data;
            }
            prev = curr;
            curr = curr->next;
        }
        throw std::runtime_error("Element not found!");
    }

    // ll_find() - Finds the first node matching target using compfunc
    T* ll_find(T target, int (*compfunc)(T, T)) {
        Node<T>* temp = head;
        while (temp) {
            if (compfunc(temp->data, target) == 0) {
                return &(temp->data);
            }
            temp = temp->next;
        }
        return nullptr;
    }

    // ll_size() - Returns the size of the list
    int ll_size() const {
        return size;
    }

    // ll_clear() - Clears the list and frees data using freefunc
    void ll_clear(void (*freefunc)(T)) {
        Node<T>* temp = head;
        while (temp) {
            freefunc(temp->data);
            Node<T>* next = temp->next;
            delete temp;
            temp = next;
        }
        head = nullptr;
        size = 0;
    }

    // ll_map() - Traverses the list and applies mapfunc to each node's data
    void ll_map(void (*mapfunc)(T)) {
        Node<T>* temp = head;
        while (temp) {
            mapfunc(temp->data);
            temp = temp->next;
        }
    }

    // Display list contents
    void display() const {
        Node<T>* temp = head;
        while (temp) {
            std::cout << temp->data << " -> ";
            temp = temp->next;
        }
        std::cout << "NULL" << std::endl;
    }

    // Destructor to free memory
    ~LinkedList() {
        Node<T>* temp;
        while (head) {
            temp = head;
            head = head->next;
            delete temp;
        }
    }
};