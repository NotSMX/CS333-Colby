# CS333 - Project 4 - README
### Daniel Yu
### 3/22/2025

***Google Sites Report: https://sites.google.com/colby.edu/dans-cs333/home?authuser=1 ***

## Directory Layout:
```
Project4_dyu/
├── C
│   ├── clltest
│   ├── clltest.c
│   ├── extension1
│   ├── extension1.c
│   ├── linkedlist.c
│   ├── linkedlist.h
│   ├── quicksort
│   ├── quicksort.c
│   ├── task2
│   └── task2.c
├── C++
│   ├── extension
│   ├── extension.cpp
│   ├── task1
│   ├── task1.cpp
│   ├── task2
│   ├── task2.cpp
│   └── task2test.cpp
├── Javascript
│   ├── extension.js
│   ├── task1.js
│   ├── task2.js
│   └── task2test.js
├── README.md
└── images
    ├── ctask1.png
    ├── ctask2.png
    ├── ctask3_1.png
    ├── ctask3_2.png
    └── extension3.png
```
## OS and C compiler
OS: Microsoft Windows Version 24H2 (OS Build 26100.2894)
C compiler: gcc (Ubuntu 13.3.0-6ubuntu2~24.04) 13.3.0

## Part I 
### Task 1
**Compile:** $ gcc -o quicksort quicksort.c

**Run:** $ ./quicksort

**Output:**
![Screenshot of task 1-3's output](images/ctask1.png)

**Q.b.** The qsort() function in C uses a comparator function that returns: A negative value if the first element should come before the second. Zero if they are considered equal. A positive value if the first element should come after the second. The comparator function first checks the parity of two numbers. If one number is even and the other is odd, it ensures that the even number appears first. If both numbers are even, they are sorted in descending order by returning b - a. If both numbers are odd, they are sorted in ascending order by returning a - b. 

### Task 2
**Compile:** $ gcc -o task2 task2.c

**Run:** $ ./task2

**Q.b.** The implementation of the factorial function demonstrates two key concepts in C: function pointers and integer overflow. By declaring a function pointer int (*calc)(const int) and assigning it to the factorial function, the program shows how functions in C can be treated as first-class entities, allowing them to be referenced and called dynamically. This illustrates the flexibility of function pointers, which are commonly used in callback functions and dynamic function execution. 

**Output:**
![Screenshot of multiple factorial outputs](images/ctask2.png)

**Q.c.** When updating the program to accept a command-line argument and compute the factorial of the given number, an important limitation of the int data type is revealed. While the factorial of 12 (479001600) is computed correctly, calculating 13!, 14!, and 15! results in incorrect outputs due to integer overflow. This occurs because the factorial grows exponentially, exceeding the maximum limit of a 4-byte integer (2,147,483,647). As a result, the computed values wrap around, producing seemingly random incorrect numbers. This experiment highlights the importance of choosing the appropriate data type for large computations, such as using long long or arbitrary-precision libraries for handling extremely large numbers. The overall takeaway is that understanding data type limits and function pointer usage is essential for writing efficient and reliable C programs.

### Task 3
**Compile:** $ gcc -o clltest clltest.c linkedlist.c

**Run:** $ ./clltest

**Output:**
![Screenshot of clltest's output for part of datatype1](images/ctask3_1.png)
![Screenshot of clltest's output for the other part of datatype 1 and datatype2](images/ctask3_2.png)

**Q.b.** The implementation of the factorial function demonstrates two key concepts in C: function pointers and integer overflow. By declaring a function pointer int (*calc)(const int) and assigning it to the factorial function, the program shows how functions in C can be treated as first-class entities, allowing them to be referenced and called dynamically. This illustrates the flexibility of function pointers, which are commonly used in callback functions and dynamic function execution. 

**Q.c.** The ll_clear function deallocates all nodes, but the data stored in the nodes may have been dynamically allocated (e.g., using malloc or strdup). If freefunc is not used, memory allocated for data will not be freed, leading to memory leaks.

## Part II
### Task 1
**Compile:** $ g++ -o task1 task1.cpp

**Run:** $ ./task1

**Output:** Please see on Google Site: https://sites.google.com/colby.edu/dans-cs333/project-4-c?authuser=1

### Task 2
**Compile:** $ g++ -o task2 task2test.cpp

**Run:** $ ./task2

**Output:** Please see on Google Site: https://sites.google.com/colby.edu/dans-cs333/project-4-c?authuser=1

## Extensions

### Extension 1
**Description**
Firstly, I explored the precedence and semantics of the C memory operators.

**Compile:** $ gcc -o extension1 extension1.c

**Run:** $ ./extension1

**Output:** 
  The result: 0
  The result: 55 
  The result: 59
  The result: 55
  The result: 2
  The result: 58
  a is not equal to b
  a is greater than b

For the first part of our extension, we explored the various precedence and semantics in the C memory operators to gain a better understanding on how C processes them. We were able to learn that * / % have all of the same precedence, therefore when put in a line together, the associativity goes from left to right, which are shown with the output above. This can also be in the case for + -. However, when having all the operators together, then * / % are priortized before + -. An interesting found was that C supports bitwise operators, where these operators work on bits and perform bit-by-bit operation. In other words, to perform operations on the data at a bit level. 

### Extension 2
**Description**
I then did task 2 for Javascript.

**Run:** $ node task1.js | node task2.js

**Output:** Please see on Google Site: https://sites.google.com/colby.edu/dans-cs333/project-4-c?authuser=1

### Extension 3
**Description**
I then implemented the delete function for my linked list in C that can remove the node at any given position in the list.

**Compile:** $ gcc -o clltest clltest.c linkedlist.c

**Run:** $ ./clltest

**Output:** 
![Screenshot of clltest's output adding the delete function](images/extension3.png)

### Extension 4
**Description**
Finally, I explored how memory operators worked in both C++ and Javascript.

**Compile C++:** $ g++ -o extension extension.cpp

**Run C++:** $ ./extension
**Run Java:** $ node extension.js

**Output:** Please see on Google Site: https://sites.google.com/colby.edu/dans-cs333/project-4-c?authuser=1