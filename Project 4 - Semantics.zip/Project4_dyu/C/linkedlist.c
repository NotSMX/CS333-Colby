/**
 * Linked List Implementation
 * Daniel Yu
 * March 22, 2025
 */

#include "linkedlist.h"

// Create a new linked list
LinkedList *ll_create() {
    LinkedList *l = (LinkedList *)malloc(sizeof(LinkedList));
    if (!l) return NULL;
    l->head = NULL;
    return l;
}

// Push data to the front of the list
void ll_push(LinkedList *l, void *data) {
    Node *new_node = (Node *)malloc(sizeof(Node));
    if (!new_node) return;
    new_node->data = data;
    new_node->next = l->head;
    l->head = new_node;
}

// Pop and return data from the front
void *ll_pop(LinkedList *l) {
    if (!l->head) return NULL;
    Node *temp = l->head;
    void *data = temp->data;
    l->head = l->head->next;
    free(temp);
    return data;
}

// Append data to the end of the list
void ll_append(LinkedList *l, void *data) {
    Node *new_node = (Node *)malloc(sizeof(Node));
    if (!new_node) return;
    new_node->data = data;
    new_node->next = NULL;

    if (!l->head) {
        l->head = new_node;
        return;
    }

    Node *current = l->head;
    while (current->next) {
        current = current->next;
    }
    current->next = new_node;
}

// Remove the first matching node
void *ll_remove(LinkedList *l, void *target, int (*compfunc)(void *, void *)) {
    if (!l->head) return NULL;

    Node *current = l->head;
    Node *prev = NULL;

    while (current) {
        if (compfunc(current->data, target) == 0) {
            void *data = current->data;
            if (prev)
                prev->next = current->next;
            else
                l->head = current->next;
            free(current);
            return data;
        }
        prev = current;
        current = current->next;
    }
    return NULL;
}

//EXTENSION: DELETE GIVEN POSITION
void *ll_delete(LinkedList *l, int position, int (*compfunc)(void *, void *)) {
    if (!l->head) return NULL;

    Node *current = l->head;
    Node *prev = NULL;

    for (int counter = 0; counter < position; counter++) {
        prev = current;
        current = current->next;
    }
    void *data = current->data;
    if (prev)
        prev->next = current->next;
    else
        l->head = current->next;
    free(current);
    return data;
}

// Find and return the first matching node's data
void *ll_find(LinkedList *l, void *target, int (*compfunc)(void *, void *)) {
    Node *current = l->head;
    while (current) {
        if (compfunc(current->data, target) == 0)
            return current->data;
        current = current->next;
    }
    return NULL;
}

// Return the size of the list
int ll_size(LinkedList *l) {
    int count = 0;
    Node *current = l->head;
    while (current) {
        count++;
        current = current->next;
    }
    return count;
}

// Clear all nodes, freeing the data
void ll_clear(LinkedList *l, void (*freefunc)(void *)) {
    Node *current = l->head;
    while (current) {
        Node *temp = current;
        current = current->next;
        if (freefunc)
            freefunc(temp->data);
        free(temp);
    }
    l->head = NULL;
}

// Apply a function to each element
void ll_map(LinkedList *l, void (*mapfunc)(void *)) {
    Node *current = l->head;
    while (current) {
        mapfunc(current->data);
        current = current->next;
    }
}
