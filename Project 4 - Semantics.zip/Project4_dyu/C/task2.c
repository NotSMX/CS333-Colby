/**
 * Write a function that takes in an integer argument and returns its factorial value as an integer.
 *
 * Daniel Yu
 * 03/20/2025
 */

#include <stdio.h>
#include <stdlib.h>

/* Function to calculate factorial */
int factorial(const int n) {
    if (n < 0) return -1;  // Return -1 for invalid input
    int result = 1;
    for (int i = 1; i <= n; i++) {
        result *= i;
    }
    return result;
}

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: %s <integer>\n", argv[0]);
        return 1;
    }

    // int N = 1;
    int N = atoi(argv[1]);  // Convert command-line argument to an integer
    int (*calc)(const int) = factorial;  // Function pointer assignment

    int result = calc(N);
    if (result < 0) {
        printf("Factorial is undefined for negative numbers.\n");
    } else {
        printf("Factorial of %d is %d\n", N, result);
    }

    return 0;
}
