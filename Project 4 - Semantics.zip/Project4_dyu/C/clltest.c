/*
    Bruce Maxwell
    Fall 2012
    CS 333

    Extended Linked list test function to support strings
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "linkedlist.h"

// Function to print an integer
void printInt(void *i) {
    printf("value: %d\n", *(int *)i);
}

// Function to square an integer
void squareInt(void *i) {
    int *a = (int *)i;
    *a = (*a) * (*a);
}

// Function to compare two integers
int compInt(void *i, void *j) {
    return (*(int *)i == *(int *)j);
}

// Function to print a string
void printString(void *s) {
    printf("value: %s\n", (char *)s);
}

// Function to convert a string to uppercase
void uppercaseString(void *s) {
    char *str = (char *)s;
    while (*str) {
        if (*str >= 'a' && *str <= 'z') {
            *str -= 32;  // Convert lowercase to uppercase
        }
        str++;
    }
}

// Function to compare two strings
int compString(void *s1, void *s2) {
    return strcmp((char *)s1, (char *)s2) != 0;
}

// Main test function
int main(int argc, char *argv[]) {
    LinkedList *l;
    int *a;
    int *target;
    int i;

    // ---- Integer Linked List Test ----
    printf("========== Integer Linked List Test ==========\n");
    
    // create a list
    l = ll_create();

    // push data on the list
    for (i = 0; i < 20; i += 2) {
        a = malloc(sizeof(int));
        *a = i;

        ll_push(l, a);
    }

    // printing the list and testing map
    printf("After initialization\n");
    ll_map(l, printInt);

    ll_map(l, squareInt);

    printf("\nAfter squaring\n");
    ll_map(l, printInt);

    // testing removing data
    target = malloc(sizeof(int));

    *target = 16;
    a = ll_remove(l, target, compInt);
    if (a != NULL)
        printf("\nremoved: %d\n", *a);
    else
        printf("\nNo instance of %d\n", *target);

    *target = 11;
    a = ll_find(l, target, compInt);
    if (a != NULL)
        printf("\nFound: %d\n", *a);
    else
        printf("\nNo instance of %d\n", *target);
    a = ll_remove(l, target, compInt);
    if (a != NULL)
        printf("\nremoved: %d\n", *a);
    else
        printf("\nNo instance of %d\n", *target);

    printf("\nAfter removals\n");
    ll_map(l, printInt);

    // testing appending data
    ll_append(l, target);

    printf("\nAfter append\n");
    ll_map(l, printInt);

    // test clearing
    ll_clear(l, free);

    printf("\nAfter clear\n");
    ll_map(l, printInt);

    // rebuild and test append and pop
    for (i = 0; i < 5; i++) {
        a = malloc(sizeof(int));
        *a = i;
        ll_append(l, a);
    }

    printf("\nAfter appending\n");
    ll_map(l, printInt);

    a = ll_pop(l);
    printf("\npopped: %d\n", *a);
    free(a);

    a = ll_pop(l);
    printf("popped: %d\n", *a);
    free(a);

    printf("\nAfter popping\n");
    ll_map(l, printInt);

    printf("\nList size: %d\n", ll_size(l));

    // ---- String Linked List Test ----
    printf("\n========== String Linked List Test ==========\n");

    LinkedList *str_list = ll_create();
    char *s1 = strdup("hello");
    char *s2 = strdup("world");
    char *s3 = strdup("linked");
    char *s4 = strdup("list");

    // Push strings into the list
    ll_push(str_list, s1);
    ll_push(str_list, s2);
    ll_push(str_list, s3);
    ll_push(str_list, s4);

    // Print initial list
    printf("After initialization:\n");
    ll_map(str_list, printString);

    // Convert all strings to uppercase
    ll_map(str_list, uppercaseString);
    printf("\nAfter converting to uppercase:\n");
    ll_map(str_list, printString);

    char *target_str = malloc(sizeof(char));
    target_str = "WORLD";
    char *b = ll_find(str_list, target_str, compString);
    if (b != NULL)
        printf("\nFound: %s\n", b);
    else
        printf("\nNo instance of %s\n", target_str);

    // Remove a string from the list
    char *removed_str = ll_remove(str_list, target_str, compString);
    if (removed_str != NULL) {
        printf("\nRemoved: %s\n", removed_str);
        free(removed_str);
    } else {
        printf("\nNo instance of %s\n", target_str);
    }
    
    target_str = "TEST MESSAGE";
    removed_str = ll_remove(str_list, target_str, compString);
    if (removed_str != NULL) {
        printf("\nRemoved: %s\n", removed_str);
        free(removed_str);
    } else {
        printf("\nNo instance of %s\n", target_str);
    }

    printf("\nAfter removals:\n");
    ll_map(str_list, printString);

    // Clear string list
    ll_clear(str_list, free);

    printf("\nAfter clear\n");
    ll_map(str_list, printString);

     // rebuild and test append and pop
     char *s5 = strdup("this");
     char *s6 = strdup("my");
     char *s7 = strdup("second");
     char *s8 = strdup("test");

     // Push strings into the list
     ll_append(str_list, s5);
     ll_append(str_list, s6);
     ll_append(str_list, s7);
     ll_append(str_list, s8);

    printf("\nAfter appending\n");
    ll_map(str_list, printString);

    b = ll_pop(str_list);
    printf("\npopped: %s\n", b);
    free(b);

    b = ll_pop(str_list);
    printf("popped: %s\n", b);
    free(b);

    printf("\nAfter popping\n");
    ll_map(str_list, printString);

    printf("\nList size: %d\n", ll_size(str_list));

    //extension
    ll_delete(str_list, 1, compString);
    printf("\nAfter removing the second index\n");
    ll_map(str_list, printString);

    return 0;
}
