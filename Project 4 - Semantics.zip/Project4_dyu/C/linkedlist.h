/**
 * Linked List Prototype
 * Daniel Yu
 * March 22, 2025
 */


#ifndef LINKEDLIST_H
#define LINKEDLIST_H

#include <stdio.h>
#include <stdlib.h>

// Node structure
typedef struct Node {
    void *data;
    struct Node *next;
} Node;

// LinkedList structure
typedef struct {
    Node *head;
} LinkedList;

// Function prototypes
LinkedList *ll_create();
void ll_push(LinkedList *l, void *data);
void *ll_pop(LinkedList *l);
void ll_append(LinkedList *l, void *data);
void *ll_remove(LinkedList *l, void *target, int (*compfunc)(void *, void *));
void *ll_delete(LinkedList *l, int index, int (*compfunc)(void *, void *));
void *ll_find(LinkedList *l, void *target, int (*compfunc)(void *, void *));
int ll_size(LinkedList *l);
void ll_clear(LinkedList *l, void (*freefunc)(void *));
void ll_map(LinkedList *l, void (*mapfunc)(void *));

#endif
