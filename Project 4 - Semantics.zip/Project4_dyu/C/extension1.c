/**
 * A program that covers the precedence and semantics of the C memory operators like 
 * & and *
 * AN EXTENSION FOR THE LANGUAGE C
 * 
 * extension1.c
 * Daniel Yu
 * March 22, 2025
 */


#include <stdio.h>
#include <stdlib.h>

int main (int argc, char **argv) {
    /*
    Operator precedence determins which operation is performed first in an expression with more
    than one operators with different precedence
    */

    /*
    Starting off with * / % - all three of these operations have the same 
    precedence, where their associativity goes from left to right
    */
    //for example,
    int a = 50;
    int b = 10;
    int c = 5;

    //therefore, a with get divided by b, and the quotient will be multipled by c, where 
    //finally the product is mod by 1.
    int result = a / b * c % 1;
    printf("The result: %d", result);

    /*
    Next, +, -  have the same 
    precedence, where their associativity also goes from left to right
    */
    //for example,
    //where a gets added to b and then the sum going from left to right
    int result2 = a + b - c;
    printf("\nThe result: %d ", result2);

    /*
    Now, when combining all the operations together,  * / %, and +,-
    */
    //the *, /, %, will perform first before the + -, therefore, those operations will finish
    //and then read the operations from left to right going from addition, to subtraction, to addition
    //in other words, 10 * 5 = 50 / 5 = 10 % 6 = 4 
    //go back to the addition, so 50 + 10 = 60 - 5 = 55 + 4 =59
    int result3 = a + b - c + b * c / c % 6;
    printf("\nThe result: %d", result3);

    //if we add in parentheses, then the values inside of them, will be prioritized first
    //in this case, b will be subtracted by c first, and then the difference will be 
    //added to a
    //10-5 = 5 + 50 = 55
    int result4 = a + (b - c);
    printf("\nThe result: %d", result4);

    /*
    C also supports bitwise operators, where these operators work on bits and 
    perform bit-by-bit operation. In other words, to perform operations on the 
    data at a bit level.
    */
    //for instance, a and b have some type of binary format
    //by using the operator '&', it copies a bit to the result if
    //it exists in both operands. The value that will be printed out is the decimal
    //format of the binary formatting
    int result5 = a & b;
    printf("\nThe result: %d", result5);

    //there also exists the operator '|,' which represents the or operator. 
    //Copies a bit if it exists in either operand.
    int result6 = a|b;
    printf("\nThe result: %d", result6);


    /*
    C also has equality operators to check if two integers are the same.
    The equality operator return true if its operands are equal
    */
    if (a == b)
    {
        printf("\na and b are the same values");
    }
    else
    {
        printf("\na is not equal to b");
    }


    /*
    These operations check if a and b are less than, or greater than to one another.
    */
    if (a > b)
    {
        printf("\na is greater than b");
    }
    else
    {
        printf("\nb is greater than a");
    }

    return 0;

}
