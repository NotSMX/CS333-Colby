/*
Picks a random string from an array and prints it.

fortune.js
Daniel Yu
February 22, 2025

*/

const fortunes = [
    "You will have a great day!",
    "An adventure awaits you.",
    "Something unexpected will happen soon.",
    "You will learn something new today.",
    "Happiness is coming your way!"
];

//fortunes: the array
//Math.floor helps round Math.random since its a decimal and array indexes are integers
//Math.random times fortunes length is needed since random is 0 to 1, so multiplying by the length increases the maximum value while keeping the odds the same. Like Java!
console.log(fortunes[Math.floor(Math.random() * fortunes.length)]);