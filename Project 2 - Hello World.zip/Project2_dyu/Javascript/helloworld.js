/*
Print a "Hello, World!" once a second, 5 times.

helloworld.js
Daniel Yu
February 22, 2025

*/

let count = 0;

function repeatHello() {
    console.log("Hello, World! " + count);
    count++;

    if (count < 5) {
        setTimeout(repeatHello, 1000); // Wait 1 second, then repeat, RECURSION!!!
    }
}

repeatHello();
