int main() {

  int a = 6;
  int b = 5.0;

  if( a < b ) {
    a = a + b;
  }

}