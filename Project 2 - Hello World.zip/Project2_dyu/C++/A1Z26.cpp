/*
The A1Z26 cipher is a simple letter-to-number substitution cipher where 
each letter is replaced by its position in the alphabet (A = 1, B = 2, ..., Z = 26). 
This programs helps encode and decode messages using the A1Z26 cipher:

A1Z26.cpp
Daniel Yu
February 22, 2025

*/

#include <iostream>
#include <sstream>
using namespace std;

// encoding text
string encodeA1Z26(const string& text) {
    string result;
    for (char c : text) // for every character in text
        if (isalpha(c)) //check it's a letter
            result += to_string(toupper(c) - 'A' + 1) + " "; // subtract by the char value of A, offset by 1, add a space
    return result;
}

string decodeA1Z26(const string& code) {
    string result;
    int num = 0;
    for (char c : code) {
        if (c >= '0' && c <= '9') { // checks if we're currently reading part of a number
            num = num * 10 + (c - '0'); // Update the number (this allows for multi-digit numbers, by storing the previous number as a variable, offsetting it by a factor of ten and adding this new digit)
        } else if (c == ' ' || &c == &code.back()) { 
            // When a space is encountered, or at the end of the string, process the current number
            if (num > 0) {
                result += char('A' + num - 1); // convert int to char
                num = 0; // Reset num for the next letter
            }
        }
    }
    return result;
}

int main() {
    string text = "This is an encrypted message";
    cout << encodeA1Z26(text) << endl;
    cout << decodeA1Z26(encodeA1Z26(text)) << endl;
    return 0;
}