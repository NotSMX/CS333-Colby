/*
A 'hello world' program that's more interesting by
instead printing a ASCII pattern of "HELLO WORLD!"

helloworld.cpp
Daniel Yu
February 22, 2025

*/

#include <iostream>
using namespace std; //so I don't have to do std::cout anymore

void printPattern() {
    // make an array where each line is a different row of the ASCII Art
    const char* pattern[] = {
        "  H   H  EEEEE  L      L      OOO     W   W   OOO   RRRR   L     DDDD   |",
        "  H   H  E      L      L     O   O    W   W  O   O  R   R  L     D   D  |",
        "  HHHHH  EEEE   L      L     O   O    W W W  O   O  RRRR   L     D   D  |",
        "  H   H  E      L      L     O   O    WW WW  O   O  RRR    L     D   D",
        "  H   H  EEEEE  LLLLL  LLLLL  OOO     W   W   OOO   R  RR  LLLLL DDDD   ."
    };
    // print each line seperated by a newline
    for (const char* line : pattern) {
        cout << line << "\n";
    }
}

int main() {
    cout << "Hello, World! But let's make it interesting:\n";
    printPattern();
    return 0;
}