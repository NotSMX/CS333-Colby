# CS333 - Project 2 - README
### Daniel Yu
### 2/19/2025

***Google Sites Report: https://sites.google.com/colby.edu/dans-cs333/home?authuser=1 ***

## Directory Layout:
```
Project2_dyu/
├── C++
│   ├── A1Z26.cpp
│   ├── A1Z26.exe
│   ├── helloworld.cpp
│   └── helloworld.exe
├── Flex
│   ├── a.out
│   ├── comments.txt
│   ├── encode.yy
│   ├── encode.yy.c
│   ├── input.txt
│   ├── p2-example.c
│   ├── p2.txt
│   ├── p2_htmltest.txt
│   ├── read.yy
│   ├── task2.yy
│   ├── task2.yy.c
│   ├── task3.yy
│   ├── task3.yy.c
│   ├── task4.yy
│   └── task4.yy.c
├── Javascript
│   ├── fortune.js
│   └── helloworld.js
├── README.md
└── images
    ├── ext4.png
    ├── flextask1.png
    ├── flextask2input.png
    ├── flextask2output.png
    ├── flextask3.png
    ├── flextask3_2.png
    ├── flextask3_3.png
    ├── flextask3_4.png
    └── flextask4.png
```
## OS and C compiler
OS: Microsoft Windows Version 24H2 (OS Build 26100.2894)
C compiler: gcc (Ubuntu 13.3.0-6ubuntu2~24.04) 13.3.0

## Part I 
### task 1
**Compile:** $ flex -o encode.yy.c encode.yy
$ gcc -o repl lex.yy.c -ll

**Run:** $ echo "Whats up | ./repl

**Output:**
![Screenshot of Flex task 1](images/flextask1.png)

**Q.b.** 

You write a flex scanner to match the characters a-z and A-Z and apply the transformation (shift 13 positions) to those characters. When a character is matched, it checks whether it's in the lowercase or uppercase range, and then it shifts that character by 13 positions forward in the alphabet. The shifting uses ASCII values for the characters, and you wrap around when necessary.
Each matched character gets processed, shifting it 13 positions ahead. If the letter is 'z', it wraps around back to 'a'. Similarly, for uppercase letters, if 'Z' is reached, it wraps back to 'A'.

Character: K
ASCII Value: 75
When 'X' is inputted into the terminal, the character that is return is 'K.'
 
###task 2
**Compile:** $ flex -o task2.yy.c task2.yy

**Run:** $ ./a.out input.txt

**Output:**
![Screenshot of Flex task 2's test text](images/flextask2input.png)
![Screenshot of Flex task 2's test output](images/flextask2output.png)

**Q.b.** 

This Flex program processes a text file and reports the number of rows, total characters, and occurrences of each vowel (a, e, i, o, u). It begins by defining variables to track these counts, initializing them at the start. The core of the program consists of pattern-matching rules that increment the respective counters when specific characters are encountered. Each vowel is counted separately, while every character, including non-vowels, contributes to the total character count. Newline characters (\n) are used to track rows in the file. The main function allows the program to read input from a file, process it using yylex(), and then print the results. When tested with a sample input, the program correctly identified 2 rows, 88 characters, and the exact number of each vowel, confirming its accuracy. For example, whenever an 'a' appears in the input, the [a] pattern triggers, incrementing both the aCount and charactercount variables. The correctness of the output is verified by matching it against known input statistics (that I manually counted and typed into the test input). The program could be enhanced further by handling uppercase vowels and addressing edge cases such as empty files.

###task 3
**Compile:** $ flex -o task3.yy.c task3.yy

**Run:** 
$ ./a.out p2.txt
$ ./a.out p2_htmltest.txt

**Output:**
![Screenshot of Flex task 3](images/flextask3.png)
![2nd Screenshot of Flex task 3 (EXTREMELY LARGE, BASICALLY JUST THE CS333 COLBY PAGE)](images/flextask3_2.png)
![3rd Screenshot of Flex task 3 (EXTREMELY LARGE, BASICALLY JUST THE CS333 COLBY PAGE)](images/flextask3_3.png)

**Q.b.** 

This Flex program processes an HTML file by removing all tags, comments, and excess whitespace while preserving paragraph breaks. It uses pattern-matching rules to identify and strip specific elements. First, it matches and removes sequences of whitespace characters such as spaces, tabs, and newlines to clean up the output. When it encounters a <p> tag, it prints two newlines to maintain paragraph separation. HTML tags are identified using the pattern <[^<>]+>, which matches any text enclosed in angle brackets and removes them. This ensures that both opening and closing tags, such as <div> and </span>, are eliminated. Comments, which start with <!-- and end with -->, are also removed, though the current implementation may not handle multiline comments correctly. For example, if the input contains <h1>Hello</h1>, the rule <[^<>]+> detects <h1> and </h1>, stripping both from the output, leaving only Hello. This allows the program to preserve the text while removing unnecessary formatting elements.

###task 4
**Compile:** $ flex -o task4.yy.c task4.yy

**Run:** $ ./a.out p2-example.c

**Output:**
![Screenshot of c task 4](images/flextask4.png)

**Q.b.** 

This Flex program is designed to implement a lexical analyzer for Clite, a simplified programming language. The program reads input from a text file and classifies each token, printing its type and value. It first defines patterns for different token types, such as integers, floating-point numbers, keywords, identifiers, operators, and punctuation. The FLOAT token is specifically defined by the pattern [0-9]\.[0-9], which matches a numeric value containing a decimal point. When a floating-point number is encountered, the rule {FLOAT} {printf("Float-%s\n", yytext);} is triggered. This prints the token type (Float) followed by the matched text. For example, if the input contains 3.1, the lexer recognizes it as a floating-point number and outputs Float-3.1. This ensures that numerical values with decimal points are correctly identified and distinguished from integers. 

## Part II
**Compile:** $ g++ -o helloworld helloworld.cpp

**Run:** $ ./helloworld

**Output:** Please see on Google Site: https://sites.google.com/colby.edu/dans-cs333/project-2-c?authuser=1

## Extensions

###extension 1
**Description**
I created a program that encodes and decode Strings based on the A1Z26 cipher in C++, my second langauge.

**Compile:** $ g++ -o A1Z26 A1Z26.cpp

**Run:** $ ./A1Z26

**Output:** Please see on Google Site: https://sites.google.com/colby.edu/dans-cs333/project-2-c?authuser=1

###extension 2
**Description**
I created a program that prints multiple "Hello, World!"s in 1 second intervals on Javascript.

**Run:** $ node helloworld.js

**Output:** Please see on Google Site: https://sites.google.com/colby.edu/dans-cs333/project-2-javascript?authuser=1

###extension 3
**Description**
I created a program that prints a random "fortune" or phrase based on random integer generation in Javascript.

**Run:** $ node fortune.js

**Output:** Please see on Google Site: https://sites.google.com/colby.edu/dans-cs333/project-2-javascript?authuser=1

###extension 4
**Description**
The last extension I have done was ignore the comments of code when a CLITE parser reads a file. I've tested out multiple types of comments within the test txt file from task 4, so to confirm it works, I should get the same output as from task4.

**Compile:** $ flex -o task4.yy.c task4.yy

**Run:** $ ./a.out comments.txt

**Output:**
![Screenshot of c task 4](images/ext4.png)