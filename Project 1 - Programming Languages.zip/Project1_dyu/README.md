# CS333 - Project 1 - README
### Daniel Yu
### 2/8/2025

***Google Sites Report: https://sites.google.com/colby.edu/dans-cs333/project-1?pli=1&authuser=1 ***

## Directory Layout:
```
proj01/
|
|__/C/
|  |
|  |__/task1.c
|  |__/task2.c
|  |__/task3.c
|  |__/task4.c
|  |__/task5.c
|  |__/ext1.c
|  |__/ext2.c
|__/images/
|  |
|__|__|ctask1.png
|__|__|ctask1_2.png
|__|__|ctask2_1.png
|__|__|ctask2_2.png
|__|__|ctask2_3.png
|__|__|ctask2_4.png
|__|__|ctask3.png
|__|__|ctask4.png
|__|__|ctask5_1.png
|__|__|ctask5_2.png
|__|__|ext1.png
```
## OS and C compiler
OS: Microsoft Windows Version 24H2 (OS Build 26100.2894)
C compiler: gcc (Ubuntu 13.3.0-6ubuntu2~24.04) 13.3.0

## Part I 
### task 1
**Compile:** $ gcc -o task1 task1.c

**Run:** $ ./task1

**Output:**
![Screenshot of c task 1](images/ctask1.png)
![2nd Screenshot of c task 1](images/ctask1_2.png)

**Q.b.** 

Based on the output text, my machine can be determined to be little-endian.

**Q.c.** 

Little endian byte orders are when the least significant byte is stored at the lowest memory address. The value of each variable was set to 12345, which in hexadecimal is 3039. 39 is less significant than 30, and it is at the lowest memory address 0 for short, int and long. Floats and Doubles work differently, in that they have their own IEEE formatting when it comes to binary, which is why their values start at the highest memory address instead. Nonetheless, all variables point to my machine being little-endian.
 
###task 2
**Compile:** $ gcc -o task2 task2.c

**Run:** $ ./task2

**Output:**
![Screenshot of c task 2](images/ctask2_1.png)
![2nd Screenshot of c task 2](images/ctask2_2.png)
![3rd Screenshot of c task 2](images/ctask2_3.png)
![4th Screenshot of c task 2](images/ctask2_4.png)

**Q.b.** 

The stack seems to be filled with random values or hexadecimal entries that have no obvious pattern to them.

**Q.c.**

I can't really determine anything about the non-zero entries. Because the main memory is so large, most of the data addresses might just be filled up with random portions of data on my laptop.

**Q.d.**

The variables I called all had values of 0x12345678, which if I was lucky would show up as 78 56 34 12 within these 100 lines, but unfortunately it doesn't seem to be the case. I did add a char 'A' (which in hexadecimal is 41) so it's possible that 70 : 41 is that variable but I can't say for sure.

###task 3
**Compile:** $ gcc -o task3 task3.c

**Run:** $ ./task3

**Output:**
![Screenshot of c task 3](images/ctask3.png)

**Q.b.** 

When the free statement is used, the memory is approximately 3 times more "free" than when the statement is not used. Specifically, when memory is not freed, the iteration runs till around 7842 iterations, when when memory is freed, goes up to 21500 iterations.

###task 4
**Compile:** $ gcc -o task4 task4.c

**Run:** $ ./task4

**Output:**
![Screenshot of c task 4](images/ctask4.png)

**Q.b.** 

From the first task, it would be assumed that the amount of bytes to represent a char, two shorts and an int would just be the sum of their original byte sizes. A char took 1 byte, a short took 2 bytes, and an integer took 4 to represent. So it would be reasonable to believe that it would take 1 + 2 + 2 + 4 = 9 bytes to represent all memory bytes. However, I was wrong, I resulted in a length of 12 bytes.

**Q.c.**

There are gaps in the way the fields of the structure are laid out since the biggest byte type size in terms of my struct is the integer since an integer takes four bytes, as a result of char only taking one byte, the char would take an extra three bytes to match int, resulting in the total size to be 12. Therefore, there exists "extra null" bytes that cause gaps in how the structure is demonstrated. 

###task 5
**Compile:** $ gcc -o task5 task5.c

**Run:** $ ./task5

**Output:**
![Screenshot of c task 5](images/ctask5_1.png)

**Q.a.** 

Below is an example of a string that doesn't work. This is just a name of a bunch of 13 0s. The issue with BankExample.c arises due to a buffer overflow vulnerability in how user input is handled. The name field in the Account struct is defined as a fixed 10-character array, but scanf("%[^\n]s", newAccount.name); allows the user to input an unlimited number of characters. The buffer overflow supposedly occurs at 13 characters because of how the Account struct is laid out in memory. 

**Q.b.** 

![2nd Screenshot of c task 5](images/ctask5_2.png)

**Q.c.**

The name field is a fixed-size 10-character array, followed by an int (typically 4 bytes on most systems). Structs in C often have padding to align data types for efficient memory access. Since name is 10 bytes, the compiler likely adds 2 bytes of padding to align the following int balance to a 4-byte boundary. This results in balance starting at byte 12, meaning any input exceeding 12 characters (including the null terminator) will overwrite balance. When the user inputs 13 or more characters, the last few characters directly modify the balance variable, potentially setting it to an unintended positive value.

By examining the memory layout using an unsigned char * and printing raw memory contents, we can observe how extra characters overwrite the balance field.

Since balance is a 4-byte int, its memory was initially 00 00 00 00 (zero). After the overflow, the first byte of balance got set to 0x30 ('0'), making the value 30 00 00 00 in little-endian order, which equals 48 in decimal.

## Extensions
###extension 1
**Description**
I found an example of a floating point number in C, which when added one, the same number is resulted back.

**Compile:** $ gcc -o ext1 ext1.c

**Run:** $ ./ext1

**Output:** 
![Screenshot of c ext1](images/ext1.png)

###extension 2
**Question**
What other kinds of run-time errors can you generate with very simple C programs?

**Answer:** Run-time errors that can be generated from simple C code include numbers being divided by zero, when a certain variable is not defined in code, and
    when an array is created n a heap but the data is not deleted, which can result in a memory leak. 

###extension 3
**Description**
I researched a 5th programming language Scratch and included a paragraph description for the language and added it to the Google Site.

**Compile:** None, it is on the site.

**Run:** None, it is on the site.

**Output:** None, it is on the site.

###extension 4
**Description**
I fixed task 5 to be more robust, in that the initial input wouldn't affect the initial balance. To prevent memory leaks, I made 2 contengencies: 
1, I limited the input so that only 9 characters are read from the input, so that there is no buffer overflow.
2, I explicitly set the intial balance to 0 at the end.

**Compile:** $ gcc -o ext2 ext2.c

**Run:** $ ./ext2

**Output:** 
![Screenshot of c ext2](images/ext2.png)