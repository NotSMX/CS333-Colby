/**
 * This program repeatedly allocates a small amount of memory in a loop that goes on for a long time.
 *
 * Daniel Yu
 * 2/5
 */

#include <stdio.h>
#include <stdlib.h>
        
int main (int arg, char *argv[]) {	
    unsigned char *ptr;
    // A for loop that allocates memory for a long time
    for (int i = 0; i >= 0; i++) {
        //allocate memory using a pointer
        ptr = (unsigned char *) malloc(sizeof(unsigned char));
        printf("%d: %02X\n", i, ptr[i]);
        //free(ptr);
    }
    return 0;
}  
    