/**
 * @file BankExample.c
 * @author Max Bender
 * @date 2024-01-22
 * 
 * A goofy example to demonstrate need for care when managing strings in C.
 *
 * Modified by Ying Li 08/15/2024
 * Improved again by Daniel Yu 02/08/2025
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/**
 * This creates a definition for the struct Account.
 *
 * Note that balance (an int) is saved after name in memory.
 */
typedef struct Account {
    char name[10];  // Only allows 9 characters + null terminator
    int balance;
} Account;

int main(int argc, char *argv[]) {
    Account newAccount = {"", 0};  // Ensure balance is initialized safely
    printf("Please input your name for a new bank account: ");

    /**
     * Using %9s ensures that at most 9 characters are read, preventing buffer overflow.
     * The null terminator is automatically added.
     */
    scanf("%9[^\n]s", newAccount.name);

    // Explicitly set balance after input handling to prevent unintended modifications
    newAccount.balance = 0;

    printf("Thank you %s, your new account has been initialized with balance %d.\n",
           newAccount.name, newAccount.balance);
    
    return 0;
}