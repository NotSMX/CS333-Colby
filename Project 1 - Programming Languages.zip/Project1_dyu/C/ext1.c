/**
 * Find a floating point number in C to which you can add one and get back the same number.
 *
 * Daniel Yu
 * 2/5
 */

#include <stdio.h>
#include <stdlib.h>

int main(int arg, char *argv[])
{
    //two different floats where 1 is added to float a, yet both resulted in the same output. 
    //This is since the fractional portion of 
    // a float consists of 23 bits, therefore, there needs to be 30 bits in order for the least sigificant value of a number to be dropped
    //In other words, not enough precision to distinguish. 
    float a = 90000000;
    float b = a + 1;
    printf( "%f\n", a);
    printf( "%f\n", b);
}
