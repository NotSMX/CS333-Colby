/**
 * This program allows you to see where values are on the stack
 *
 * Daniel Yu
 * 2/5
 */

#include <stdio.h>
#include <stdlib.h>
        
int main (int arg, char *argv[]) {
		
    // Declaring Types
    char c = 'A';
    short s = 0x12345678;
    int i = 0x12345678;
    long l = 0x12345678;
    float f = 0x12345678;
    double d = 0x12345678;
    unsigned char *ptr;
    ptr = &ptr;

    // For loop prints out and accesses memory in sequence using the pointer
    for (int j = 0; j < 100; j++)
    {
        printf("%d: %02X\n", j, ptr[j]);
    }
					
  return 0;
}  
    