/**
 * Observing how each variable of different types is stored
 *
 * Daniel Yu
 * 2/5
 */

#include <stdio.h>
#include <stdlib.h>

/*  write a program that declares a variable of each of the basic types (char, short, int, long, float, double) 
and assigns each one a value (your choice). Declare an unsigned char * and then go through each data type and look how it is stored in memory. 
You may want to use the sizeof function to control the for loop. Calling sizeof(double), for example, returns the number of bytes used for a double.
 */
int main(int arg, char *argv[])
{
    // Declaring Types
    char c = 'A';
    short s = 12345;
    int i = 12345;
    long l = 12345;
    float f = 12345;
    double d = 12345;
    // Declaring Pointer
    unsigned char *ptr;


    //Checking how each variable is stored in memory
    printf("Memory representation of char:\n");
    ptr = (unsigned char *)&c;
    for (int j = 0; j < sizeof(char); j++)
    {
        printf("%d: %02X\n", j, ptr[j]);
    }

    printf("\nMemory representation of short:\n");
    ptr = (unsigned char *)&s;
    for (int j = 0; j < sizeof(short); j++)
    {
        printf("%d: %02X\n", j, ptr[j]);
    }

    printf("\nMemory representation of int:\n");
    ptr = (unsigned char *)&i;
    for (int j = 0; j < sizeof(int); j++)
    {
        printf("%d: %02X\n", j, ptr[j]);
    }

    printf("\nMemory representation of long:\n");
    ptr = (unsigned char *)&l;
    for (int j = 0; j < sizeof(long); j++)
    {
        printf("%d: %02X\n", j, ptr[j]);
    }

    printf("\nMemory representation of float:\n");
    ptr = (unsigned char *)&f;
    for (int j = 0; j < sizeof(float); j++)
    {
        printf("%d: %02X\n", j, ptr[j]);
    }

    printf("\nMemory representation of double:\n");
    ptr = (unsigned char *)&d;
    for (int j = 0; j < sizeof(double); j++)
    {
        printf("%d: %02X\n", j, ptr[j]);
    }

    return 0;
}
