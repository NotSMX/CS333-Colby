/**
 * This program is a struct that has 3-4 different variables (including some char and short types) so that the minimal number of bytes it would require to construct is odd.
 *
 * Daniel Yu
 * 2/5
 */

#include <stdio.h>
#include <stdlib.h>

// A struct that has 3-4 differentvariables
struct Variables{
    char c1;
    short int c2;
    short int c3;
    int c4;
};

int main (int arg, char *argv[]) {	
    // Allocate memory for the struct
    struct Variables * var = (struct Variables *)malloc(sizeof(struct Variables));
    // Pointer
    unsigned char *ptr;
    ptr = (unsigned char *) var;
    // A for loop that allocates memory for a long time
    for (int i = 0; i < sizeof(struct Variables); i++) {
        printf("%d: %02X\n", i, ptr[i]);
    }
    return 0;
}  
    