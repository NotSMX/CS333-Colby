/*
    A program that demonstrates whether functions are basic data type in language
    Daniel Yu
    extension3C.java
    March 7th, 2025
*/

#include <iostream>
using namespace std;

/*
return type of function is void-- which means nothing is returned, therefore
functions can also be demonstrated as a data type
*/
void print()
{
    cout << "Testing the void function" << endl;

}

/*
C++ application includes a default function ("main()"), which has a return type
that indicates what type of data the function would return when executed. 
In general, functions have return types, which can be considered basic data types in language
*/
int main(int argc, char* argv[])
{
    print();

    /*
    Using the lambda function, variables can hold
    arbitrary functions
    */
    
    /*
    lambda introducer [] - denotes the start of the lambda expression
    parameter list () - operator 
    equivalent to the same method as
    void subtract() 
    */
    //in this case the lambda is holding arbitrary values
    //as it captures variables that can be used later
    auto subtract = [](int a, int b)
    {
       cout << "Difference: " << a - b;
    };

    /*
    The use of the function is to define anonymous function objects, therefore,
    in a way, for values to hold arbitrary functions
    */
    subtract(15, 5);

    return 0;
}


