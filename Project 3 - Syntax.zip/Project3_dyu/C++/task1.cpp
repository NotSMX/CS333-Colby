/*
    A program that demonstrates the rules for identifier naming, variable declarations,
    and identifier scoping.
    Daniel Yu
    task1.cpp
    March 6, 2025
 * 
*/
#include <iostream>
using namespace std;
/*
global variables are declared outside the program, also 
recongized as 'global scope.' The scope spans from the point of 
declaration to the end of the file
*/
string name;
/*
Since these variables are declared inside 'practice,'
these variables are only visible within this function,
thus having a local 'scope.'
*/
void practice()
{
    /*
    In C++, identifiers can be short names or descripitive names
    */

    /*
    Other general rules include:
    - names can contain letters, digits, underscores
    - names are case sensitive 
    - names cannot contain whitespaces or special characters
    - identifiers cannot have "types" as their name
    - first letter should be either a letter or an underscore
    */

    //short
    int a = 10;

    //descripitive
    //this is also recongized as a local variable
    int age;

    //initalize the size of the local variable
    age = 10;

    //cout = 'see-out'; used for output, and the insertion operator (<<)
    cout << "Hi, my name is: " << name << endl;

    //static variables are used to hold the initial value even through
    //function is called multiple times
    static int happiness = 8;

    //statement scope, which are when 'for, if, while, or switch'
    //statements are used
    for (int index = 0; index < 2; index++)
    {
        happiness++;
        cout << "Happiness meter: " << happiness << " ";
    }
    
}

int main()
{
    //initalizes the global variable
    name = "Daniel";
    for (int x = 0; x < 2; x++)
    {
        practice();
        cout << "\n";
    }

    return 0;
}