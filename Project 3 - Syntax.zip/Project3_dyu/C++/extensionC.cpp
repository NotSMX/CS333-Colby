/*
    A program to demonstrate a comparison between c++ and java.
    This code specifically has c++ functions
    Daniel Yu
    extensionC.cpp
    March 6, 2025
 * 
*/

/*
Unlike java, C++ uses 'include statements' or 'header files', which just 
includes standard or user-defined file in the program. 
*/
#include <iostream> //the angular brackets represent an file is imported
#include <unordered_map> //stores elements formed by the combination of a key value
//and a mapped value
using namespace std;

/*
Main function for c++:
- argc "the number of arguments on the command line"
- argv "a pointer to an array of strings that contain arguments"
*/
int main(int argc, char* argv[])
{
  
   /*
    * Syntax difference:
    * To print out a statement into the terminal,
    * unlike Java, 'cout' is used. 
    * In other words, the I/O statements are different
    */
    cout << "Hello!" << endl;   //cout = 'see-out'; used for output, and the insertion operator (<<)
    

    /*
    * Testing booleans are also different;
    * in C++ for true and false,  integer values will be outputted, where
    * nonzero integers represent true, and then zero indicates false.
    * 
    * In java, the boolean value takes in true or false, which results in them
    * getting outputted in the terminal
    */
    int x = 10;
    int y = 5;

    cout << (x == y) << endl; //will check if x and y are equal, if they are, then it returns 1. Otherwise,
    //returns 0, which is false
    //the endl prints out a new line

    /*
    Things that C++ can do, which Java can't is... the inclusion of pointers. 
    */
    string food = "Cookie";
    cout << food << endl; //the value of the food
    cout << "Memory Address: " << &food << endl; //from this statement, the memory address of food will be
    //demonstrated 

   /*
   * In terms of traversing, both programming languages can use for loops to get elements
   * from a list
   */
   string fruits[3] = {"apple", "banana", "orange"};
   for (int i = 0; i < 3; i++)
   {
      cout << fruits[i] << endl;
   }

   /*
   * In terms of aggregate types, Java does not support struct and unions 
   * which is what C++ can support.
   */
   struct income //remember to specify the name of the struct
   {
    //these are considered the member variables
    //unlike an array, a structure can contain many different
    //data types
    int age; 
    double money;
   };

   /*
   Like Java, C++ also has ways to store keys and values, in this case
   an unordered_map is implemented, which is similar to a dictionary type that 
   stores elements (keys and values) for fast retrieval

   umap to be a <string, int> type key which will contain 
   a string type and mapped value is an int type
   */
   unordered_map<string, int> umap;

   //to add values into the umap
   umap["cool!!"] = 50;
   umap["is"] = 40;
   umap["Programming Languages"] = 30;

   /*
   range-based for loop; executes a for loop over a range
   'auto' used for key and value declarations
   It is necessary to use first and second in the loop
   */
   for (auto y : umap)
   {
      cout << y.first << " " << y.second << endl;
   }


    /*
    The 'goto statement' also exists in C++
    The statement unconditionally jumps to the specified label. 
    This statement definitely ruins the flow of the program, which is why it is suggested
    to be avoided for using. 
    */
   ineligible:
      cout <<"You are not eligible to drive!" << endl;
      cout << "Enter your age:";

      int age;
      cin >> age; //also compared to Java, C++ uses 'cin' for user input
      /*
      Unless you put an edge that is greater than 18, the goto will keep running.
      */
      if (age < 18)
      {
         goto ineligible;
      }
      else
      {
         cout << "You are eligible to drive!";
         return 0;
      }


    

}