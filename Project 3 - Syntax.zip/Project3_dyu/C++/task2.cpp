/*
    A program that executes a binary search on a list or array of numbers.
    Daniel Yu
    task2.cpp
    March 6, 2025
 */

#include <iostream>
using namespace std;

int binarySearch(int arr[], int index, int size)
{
    int start = 0;
    //divide the size of the array by the size
    //acquired by each element = total number
    //of elements present in array
    int end = size;

    // A while loop that repeats until the middle value
    //reaches the targeted value
    while (start <= end) {
        //first find the middle of the array
        int mid = (start + end) / 2;

        //if the middle element is equal to the index,
        //then we can return the middle index position
        if (arr[mid] == index)
        {
            return mid;
        }

        //if the value is greater than the mid element,
        //that means the targeted value, must be above the 
        //mid value, such that start will increment by one
        if (arr[mid] < index)
        {
            start = mid + 1;
        }
        //if the value is less than the mid element,
        //that means the targeted value, must be below the 
        //mid value, such that end will decrement by one
        else
        {
            end = mid - 1;
        }
    }

    //return -1 if the targeted value does not exist
    return -1;
}

int main() 
{
  int array[] = {1, 3, 6, 9, 12, 15};
  int result = binarySearch(array, 15, 6);
  if (result == -1)
    printf("Not found");
  else
    printf("Number found at index %d", result);

    return 0;
}