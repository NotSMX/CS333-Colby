/*
    A program that demonstrates all the control flow statements.
    Daniel Yu
    task4.cpp
    March 6, 2025
 */
#include <iostream>
using namespace std;

void demoFunction(int num) {
    cout << "Function called with " << num << "\n";
}

int main() {
    // 1. Conditional Statements
    int a = 10, b = 20;
    if (a < b) {
        cout << "a is less than b\n";
    } else if (a == b) {
        cout << "a is equal to b\n";
    } else {
        cout << "a is greater than b\n";
    }

    // 2. Looping Statements
    cout << "For loop: ";
    for (int i = 0; i < 3; i++) {
        cout << i << " ";
    }
    cout << "\n";

    cout << "While loop: ";
    int count = 0;
    while (count < 3) {
        cout << count++ << " ";
    }
    cout << "\n";

    cout << "Do-while loop: ";
    count = 0;
    do {
        cout << count++ << " ";
    } while (count < 3);
    cout << "\n";

    // 3. Jump Statements
    cout << "Jump statements:\n";
    for (int i = 0; i < 5; i++) {
        if (i == 2) continue; // Skip 2
        if (i == 4) break;    // Stop at 4
        cout << i << " ";
    }
    cout << "\n";

    // 4. Exception Handling (C++ only)
    try {
        throw runtime_error("An error occurred!");
    } catch (const exception &e) {
        cout << "Caught an exception: " << e.what() << "\n";
    }

    return 0;
}
