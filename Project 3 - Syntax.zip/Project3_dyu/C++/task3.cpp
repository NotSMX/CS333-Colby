/*
    A program that demonstrates all the basic built-in types and how to construct
    aggregate types. Also showcases which standard suite of operators manipulate
    which types and what type of each operation is.
    Daniel Yu
    task3.cpp
    March 6, 2025
 */

#include <iostream>
using namespace std;

/*
void is also considered a built-in type, which indicates that 
the function has no value/empty; used as a return function for functions
that do not return a specific value
*/
void example()
{
    /*
    The built-in types in C++ 
    */

    //'int' does not support any decimals or fractional number
    //allocated 4 bytes of memory space
    //can be positive or negative numbers
    int number = 10; 

    //can further be demonstrated as:
    unsigned int a; //allows positive and negative numbers
    signed int b; //only positive numbers

    //'char' accepts character values
    //these can range from digits, symbols, to letters
    //They occupy two bytes of memory space
    char c = 'A';
    char d = '$';

    //'float' represents number in decimal format, also known as 'floating-point'
    //they take up 4 bytes of memory space
    float e = 124125;
    float f = 12.34;

    //'boolean' or as a type 'bool' consists of only two values: 'True or False'
    //the default value of boolean is 'False'
    bool g = true;
    bool h = false;

    //'double' is considered a variant of the floating-point data type
    //They generally have 8 bytes of memory space allocated
    double i = 12.35;
    double j = 4677;

}

/*
A common aggregate type is 'structures,' which is used to
group several related variables into one place
*/
//to create a structure, use the 'struct' keyword
//and declare each of its members in the curly braces
struct food //remember to specify the name of the struct
{
    //these are considered the member variables
    //unlike an array, a structure can contain many different
    //data types
    int age; 
    double money;
};

/*
As C++ is an object-oriented programming language,
everything is associated with classes and objects.
Therefore, to create a class use the 'class' keyword
*/
class College
{
    /*
    By declaring the class 'public,' the members of the class
    are accessible from outside of the class.
    */
    public: //access specificer
        /*
        Inside the class, the variables are called atributes
        */
        int studentID;
        string name;
}; //end off a class with a semincolon

/*
Important to note that majority of the aggregrate types are created
using the certain type name and then having curly braces with variables within. 
For instance union and enum. Difference between struct and union is that the variables
in union cannot be used simultaneously, as a result of a value affecting the other. 
*/

/*
Standard suite of operators
*/
void example2()
{
/*
The operations that are supported by C++ are:
addition, subtraction, multiplication, division, and modulo
*/

/*
Addition, subtraction, multiplication, and division can be manipulated by
integers, floats, and doubles.
*/

/*
Integer will be resulted, if integers are +, -, * and /
*/
int a = 5;
int b = 6;
cout << "sum: " << a + b << endl;
cout << "difference: " << b - a << endl;
cout << "product: " << a * b << endl;
cout << "quotient: " << a / b << endl; //for division, because both are integers, c++ will
//disregard the remainder, and make the result an integer (integer divison)

/*
when an integer is added to a float, then the resulting number
is a float. For division, then the remainder/fractional part will be kept, in this case.
*/
float c = 7.1;
cout << "sum: " << a + c << endl;
float d = 6;
cout << "quotient: " <<d / a << endl;


/*
as a result of mod being defined as integer modular divison, mod can only work for 
two integers. Therefore, if a floating-point type is used
a compile-time error will be demonstrated
*/
int e = 10;
int f = 5;
cout << "remainder: " << e % f << endl;

}


int main() 
{
    //endl flushes out a new line
    /*
    to access the members of a structure,
    you need to use the dot syntax '.' and a struct object
    should be created. From there, 
    values can be assigned to the members of the struct
    */
    struct food f;
    f.age = 19;
    f.money = 20;

    //print out the member's values
    cout << "Age: " << f.age << endl;
    cout << "Money: " << f.money << endl;

    /*
    to access the class attributes, similar to structure,
    the dot syntax should be demonstrated and a class object should
    be created. Multiple class objects can be created. 
    */
    College myObj; //creates an object of the class

    //access attributes and assign them values
    myObj.studentID = 73139;
    myObj.name = "Daniel";

    //print out the member's values
    cout << "Student ID: " << myObj.studentID << endl;
    cout << "Name: " << myObj.name << endl;

    example2(); 

    return 0;
}