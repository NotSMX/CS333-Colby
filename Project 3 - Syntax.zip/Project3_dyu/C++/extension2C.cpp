/*
    A program that explores the built-in binary search in C++
    Daniel Yu
    extension2C.java
    March 7, 2025
 * 
*/

/*
The prototype for the built-in binary search in C++ follows
the parameters (startaddress, endaddress, value)
start: the address of the first element in array
end: the last element in the array
*/

#include <iostream> //the angular brackets represent an file is imported
//vectors in c++ are sequence containers representing arrays that change
//their size during runtime
#include <algorithm> // The std::binary_search function is part of the C++ 
//Standard Template Library (STL) algorithms, defined in the <algorithm> header.
#include <vector>
using namespace std;

int main(int argc, char* argv[])
{
    //create the array
    /*
    For this specific binary search, this function can only be implemented
    if the array is sorted to begin with. Otherwise, a method must be created first
    to sort the array and then apply the search
    */
    vector<int> array = {1, 2, 5, 6, 8, 10};

    // //gets the size of the array
    // int theSize = sizeof(array) / sizeof(array[0]);

    //print statement to declare what element we want to find in the array
    cout << "The value that we want to find in the array is 5" << endl;

    //if-else statement that is used to print out a certian statement
    //depending if the value is found in the array
    if (binary_search(array.begin(), array.end(), 5))
    {
        cout << "Value was found in the array!" << endl;
    }
    else
    {
        cout << "Value could not be found in the existing array" << endl;
    }

    //print statement to declare what element we want to find in the array
    cout << "The value that we want to find in the array is 22" << endl;

    //if-else statement that is used to print out a certian statement
    //depending if the value is found in the array
    if (binary_search(array.begin(), array.end(), 22))
    {
        cout << "Value was found in the array!";
    }
    else
    {
        cout << "Value could not be found in the existing array";
    }





    
}