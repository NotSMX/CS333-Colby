/*
    A program that demonstrates what you can do with Functions
    Daniel Yu
    task5.cpp
    March 6, 2025
 */
#include <iostream>
#include <functional>
using namespace std;

// Regular function
void greet() {
    cout << "Hello, World!\n";
}

// Function that takes another function as an argument
void executeFunction(void (*func)()) {
    func();
}

// Function that returns another function
function<void()> getFunction() {
    return greet;
}

int main() {
    // 1. Assigning function to a function pointer
    void (*functionPtr)() = greet;
    functionPtr(); // Call function via pointer

    // 2. Passing function as an argument
    executeFunction(greet);

    // 3. Using function (C++11+)
    function<void()> funcObj = greet;
    funcObj(); // Calls greet()

    // 4. Lambda function (anonymous function)
    auto lambda = []() { cout << "Lambda function!\n"; };
    lambda();

    // 5. Returning a function
    function<void()> returnedFunc = getFunction();
    returnedFunc();

    return 0;
}
