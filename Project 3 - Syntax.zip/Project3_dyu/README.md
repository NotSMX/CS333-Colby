# CS333 - Project 3 - README
### Daniel Yu
### 3/5/2025

***Google Sites Report: https://sites.google.com/colby.edu/dans-cs333/home?authuser=1 ***

## Directory Layout:
```
Project3_dyu/
├── C
│   ├── cstk.c
│   ├── cstk.h
│   ├── cstk2.c
│   ├── cstk2.h
│   ├── cstktest.c
│   ├── cstktest.exe
│   ├── cstktest2.c
│   ├── cstktest2.exe
│   ├── toDraw.c
│   ├── toDraw.exe
│   ├── toDraw2.c
│   └── toDraw2.exe
├── C++
│   ├── extension2C.cpp
│   ├── extension2C.exe
│   ├── extension3C.cpp
│   ├── extension3C.exe
│   ├── extensionC.cpp
│   ├── extensionC.exe
│   ├── task1.cpp
│   ├── task1.exe
│   ├── task2.cpp
│   ├── task2.exe
│   ├── task3.cpp
│   ├── task3.exe
│   ├── task4.cpp
│   ├── task4.exe
│   ├── task5.cpp
│   └── task5.exe
├── Java
│   ├── extension.class
│   └── extension.java
├── Javascript
│   ├── task1.js
│   ├── task2.js
│   ├── task3.js
│   ├── task4.js
│   └── task5.js
├── README.md
└── images
    ├── ctask1.png
    ├── ctask4.mp4
    ├── ctask5_1.png
    ├── ctask5_2.png
    ├── ctask6_1.png
    └── ctask6_2.png
```
## OS and C compiler
OS: Microsoft Windows Version 24H2 (OS Build 26100.2894)
C compiler: gcc (Ubuntu 13.3.0-6ubuntu2~24.04) 13.3.0

## Part I 
### Task 1 - 3
**Compile:** $ gcc -o cstktest cstktest.c cstk.c

**Run:** $ ./cstktest

**Output:**
![Screenshot of task 1-3's output](images/ctask1.png)

### Task 4

**Output:**
![Video of task 4's non consumpsion of memory](images/ctask4.mp4)

### Task 5

**Output:**
![Screenshot of task 5's Mark 1](images/ctask5_1.png)
![Screenshot of task 5's Mark 2](images/ctask5_2.png)

**Q.b.** 

Memory Layout at Mark 1 (After pushing 10 values onto the stack)
At this point, we have:
- A stack pointer (s) stored on the stack, pointing to a dynamically allocated stack structure in the heap.
- The heap structure (s->data) contains the stack array, which holds the pushed values {1, 2, 3, ..., 10}.
- The top pointer inside s points to the next available position in the data array. (11)

Memory Layout at Mark 2 (After calling stk_destroy(s))
At this point:
- The heap memory allocated for s->data (stack array) is freed.
- The heap memory allocated for the Stack structure (s) is also freed.
- The stack pointer s remains on the stack, but it now points to deallocated memory (dangling pointer).

### Task 6
**Compile:** $ gcc -o cstktest2 cstktest2.c cstk2.c

**Run:** $ ./cstktest2

**Output:**
![Screenshot of task 6's Output](images/ctask6_1.png)
![Screenshot of task 6's Mark 1](images/ctask6_2.png)


## Part II
### Task 1
**Compile:** $ g++ -o task1 task1.cpp

**Run:** $ ./task1

**Output:** Please see on Google Site: https://sites.google.com/colby.edu/dans-cs333/project-3-c?authuser=1

### Task 2
**Compile:** $ g++ -o task2 task2.cpp

**Run:** $ ./task2

**Output:** Please see on Google Site: https://sites.google.com/colby.edu/dans-cs333/project-3-c?authuser=1

### Task 3
**Compile:** $ g++ -o task3 task3.cpp

**Run:** $ ./task3

**Output:** Please see on Google Site: https://sites.google.com/colby.edu/dans-cs333/project-3-c?authuser=1

### Task 4
**Compile:** $ g++ -o task4 task4.cpp

**Run:** $ ./task4

**Output:** Please see on Google Site: https://sites.google.com/colby.edu/dans-cs333/project-3-c?authuser=1

### Task 5
**Compile:** $ g++ -o task5 task5.cpp

**Run:** $ ./task5

**Output:** Please see on Google Site: https://sites.google.com/colby.edu/dans-cs333/project-3-c?authuser=1

## Extensions

### Mini Extension (Extension 0.5?)
**Description**
In some of the stack code, I made some fail code statements in case either the stack was full or empty  (e.g. Popping values from a stack that is empty, pushing values on a full stack, etc.), or if no memory is available to make the stack, aka situations that would normally cause errors. I wouldn't consider this a big extension, but its worth noting.

### Extension 1
**Description**
Firstly, I developed explicit comparison code in Java and C++ to compare and contrast one another.

**Compile C++:** $ g++ -o extensionC extensionC.cpp
**Compile Java:** javac extension.java

**Run C++:** $ ./extensionC
**Run Java:** java extension

**Output:** Please see on Google Site: https://sites.google.com/colby.edu/dans-cs333/project-3-c?authuser=1

### Extension 2
**Description**
I then implemented the bulit-in capability for binary search in C++.

**Compile:** $ g++ -o extension2C extension2C.cpp

**Run:** $ ./extension2C

**Output:** Please see on Google Site: https://sites.google.com/colby.edu/dans-cs333/project-3-c?authuser=1 

### Extension 3
**Description**
In C++, I wrote examples of when functions are considered basic data type and how a variable holds an arbitrary function.

**Compile:** $ g++ -o extension3C extension3C.cpp

**Run:** $ ./extension3C

**Output:** Please see on Google Site: https://sites.google.com/colby.edu/dans-cs333/project-3-c?authuser=1 

### Extension 4
**Description**
Lastly, I did EVERYTHING on Part II but for Javascript! (Since my goal is to also learn Javascript)

**Run:** $ (Any of the following works) node task1.js | node task2.js | node task3.js | node task4.js | node task5.js

**Output:** Please see on Google Site: https://sites.google.com/colby.edu/dans-cs333/project-3-javascript?authuser=1
