/*
    A program that demonstrates all the basic built-in types and how to construct
    aggregate types. Also showcases which standard suite of operators manipulate
    which types and what type of each operation is. (JAVASCRIPT)
    Daniel Yu
    task3.js
    March 7th, 2025
 */

// Primitive Data Types
let num = 10; // Number
let str = "Hello"; // String
let bool = true; // Boolean
let nothing = null; // Null
let notDefined; // Undefined
let bigIntNum = 12345678901234567890n; // BigInt
let uniqueID = Symbol("id"); // Symbol

console.log(typeof num, num); // number 10
console.log(typeof str, str); // string "Hello"
console.log(typeof bool, bool); // boolean true
console.log(typeof nothing, nothing); // object (special case for null)
console.log(typeof notDefined, notDefined); // undefined
console.log(typeof bigIntNum, bigIntNum); // bigint
console.log(typeof uniqueID, uniqueID); // symbol

// Arithmetic Operators with Numbers
let sum = num + 5; // Addition
let difference = num - 3; // Subtraction
let product = num * 2; // Multiplication
let quotient = num / 4; // Division
let remainder = num % 3; // Modulus (Remainder)

console.log(sum, difference, product, quotient, remainder); // 15, 7, 20, 2.5, 1

// String Operations
let greeting = str + " World!"; // Concatenation
console.log(greeting); // "Hello World!"
console.log("Length:", str.length); // String length

// Type Coercion in Operations
console.log("5" + 3); // "53" (String concatenation)
console.log("5" - 2); // 3 (Automatic type conversion)
console.log("10" / "2"); // 5 (JavaScript converts strings to numbers)
console.log(true + 1); // 2 (Boolean true is treated as 1)

// Aggregate Types (Objects, Arrays, and Classes)

// Object (Key-Value Pairs)
let person = {
    name: "Alice",
    age: 25,
    isStudent: false
};
console.log(typeof person, person); // object

// Array (Ordered Collection)
let numbers = [1, 2, 3, 4, 5];
console.log(typeof numbers, numbers); // object (Arrays are special objects)

// Class (Constructor-Based Aggregate Type)
class Animal {
    constructor(name) {
        this.name = name;
    }
    speak() {
        return `${this.name} makes a sound`;
    }
}
let dog = new Animal("Buddy");
console.log(dog.speak()); // "Buddy makes a sound"
