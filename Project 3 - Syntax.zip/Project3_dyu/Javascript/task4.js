/*
    A program that demonstrates all the control flow statements. (JAVASCRIPT)
    Daniel Yu
    task4.js
    March 7th, 2025
 */
// Conditional Statements
let num = 10;

if (num > 0) {
    console.log("Positive number");
} else if (num < 0) {
    console.log("Negative number");
} else {
    console.log("Zero");
}

// Switch Case (JavaScript supports non-integer values, unlike C)
let fruit = "apple";
switch (fruit) {
    case "banana":
        console.log("It's a banana!");
        break;
    case "apple":
        console.log("It's an apple!");
        break;
    default:
        console.log("Unknown fruit.");
}

// For Loop
for (let i = 0; i < 3; i++) {
    console.log("For loop iteration:", i);
}

// While Loop
let count = 0;
while (count < 3) {
    console.log("While loop iteration:", count);
    count++;
}

// Do-While Loop (Executes at least once)
let x = 0;
do {
    console.log("Do-while iteration:", x);
    x++;
} while (x < 3);

// For-in Loop (Iterates over object properties)
let person = { name: "Alice", age: 25 };
for (let key in person) {
    console.log(`Key: ${key}, Value: ${person[key]}`);
}

// For-of Loop (Iterates over iterable values like arrays)
let numbers = [1, 2, 3];
for (let num of numbers) {
    console.log("For-of loop value:", num);
}

// Break Statement (Exits a loop early)
for (let i = 0; i < 5; i++) {
    if (i === 3) break;
    console.log("Break at:", i);
}

// Continue Statement (Skips to the next iteration)
for (let i = 0; i < 5; i++) {
    if (i === 2) continue;
    console.log("Continue at:", i);
}

// Return Statement in a Function
function add(a, b) {
    return a + b;
}
console.log("Sum:", add(5, 7));

