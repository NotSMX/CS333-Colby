/*
    A program that demonstrates what you can do with Functions (JAVASCRIPT)
    Daniel Yu
    task5.js
    March 7th, 2025
 */
// 1. Assigning a function to a variable
let greet = function(name) {
    return "Hello, " + name;
};
console.log(greet("Alice")); // Output: Hello, Alice

// 2. Passing a function as an argument
function executeFunction(func, value) {
    return func(value);
}
console.log(executeFunction(greet, "Bob")); // Output: Hello, Bob

// 3. Returning a function from another function
function createMultiplier(factor) {
    return function(number) {
        return number * factor;
    };
}
let double = createMultiplier(2);
console.log(double(5)); // Output: 10

// 4. Using an anonymous function
let sum = function(a, b) {
    return a + b;
};
console.log(sum(3, 4)); // Output: 7

// 5. Using an arrow function (modern syntax for anonymous functions)
const square = (x) => x * x;
console.log(square(6)); // Output: 36
