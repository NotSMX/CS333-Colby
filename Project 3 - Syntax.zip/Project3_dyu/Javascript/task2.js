/*
    A program that executes a binary search on a list or array of numbers. (JAVASCRIPT)
    Daniel Yu
    task2.js
    March 7th, 2025
 */
    function binarySearch(arr, target, left = 0, right = arr.length - 1) { //recursion!
        if (left > right) return -1; // Base case: Not found
    
        let mid = Math.floor((left + right) / 2); //find middle of  array
    
        if (arr[mid] === target) return mid; // in case you landed on it
        if (arr[mid] < target) return binarySearch(arr, target, mid + 1, right);
        return binarySearch(arr, target, left, mid - 1);
    }
    
    // Example usage:
    let numbers = [1, 3, 5, 7, 9, 11];
    console.log(binarySearch(numbers, 7)); // Output: 3
    console.log(binarySearch(numbers, 2)); // Output: -1
    