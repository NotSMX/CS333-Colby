/*
    A program that demonstrates the rules for identifier naming, variable declarations,
    and identifier scoping. (JAVASCRIPT)
    Daniel Yu
    task1.js
    March 6, 2025
 * 
*/
// Valid identifier names (cannot start with a number or contain special characters except _ and $)
let firstName = "Daniel";
const MAX_VALUE = 100; // Constants are typically written in uppercase
let _underscore = 42;
let $dollarSign = "Valid";

// Variable declarations: var (function-scoped), let/const (block-scoped)
function testScoping() {
    var a = "Function scoped"; // Accessible only in this function
    if (true) {
        let b = "Block scoped"; // Accessible only in this block
        console.log(b); 
    }
    console.log(a); // Works
    // console.log(b); // Error: b is not defined
}
testScoping();
