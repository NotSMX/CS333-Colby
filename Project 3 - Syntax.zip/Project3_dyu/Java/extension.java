/*
    A program to demonstrate a comparison between c++ and java.
    This code specifically has java functions
    Daniel Yu
    extension.java
    March 6, 2025
 * 
*/

/*
How to run:
javac extension.java
java extension

*/

/*
 * Unlike C++, Java has import statements, where it can import
 * other class files
 */
//import java.util.Random;
//import java.util.ArrayList;
import java.util.*;
import java.util.Scanner;
import java.util.HashMap;

public class extension
{
    /*
     * an array of strings that contain arguments
     */
    public static void main(String[] args)
    {
        /*
         * Syntax difference:
         * To print out a statement into the terminal,
         * unlike C++, 'System.out.println' lines are used. 
         * In other words, the I/O statements are different
         */
        System.out.println("Hello!");

        /*
         * Testing booleans are also different;
         * in C++ for true and false,  integer values will be outputted, where
         * nonzero integers represent true, and then zero indicates false.
         * 
         * In java, the boolean value takes in true or false, which results in them
         * getting outputted in the terminal
         */
        int x = 10;
        int y = 5;
        //This statement is checking if x and y have equal values, if they are equal,
        //then it should return true, otherwise, false 
        System.out.println(x == y);


        /*
         * In terms of traversing, both programming languages can use for loops to get elements
         * from a list
         */
        ArrayList<String> food = new ArrayList<String>();
        food.add("pizza");
        food.add("cake");
        food.add("brownie");
        for (int i = 0; i < food.size(); i++)
        {
            System.out.println(food.get(i));
        }

        /*
         * Java has a HashMap that stores the data in (Key, Value) pairs, which is 
         * also something similar to what C++ has, as well. 
         */
        HashMap<String, Integer> states = new HashMap<String, Integer>();
        states.put("New Jersey", 50);
        states.put("New York", 20);
        states.put("California", 28);
    
        if (states.containsKey("New Jersey"))
        {
            Integer state = states.get("New Jersey");
            System.out.println("The state New Jersey is associated with the value: " + state);
        }


        /*
         * Unlike C++, for user input in java, the scanner class is used
         * to get input, which is found from the java.util package
         * To be able to use the Scanner class, a object must be created
         */

        //creates a scanner object
        Scanner scanner = new Scanner(System.in);

        //Then the user is asked to input a number
        System.out.print("Type a number: ");

        //reads the user input
        String num = scanner.nextLine();
        
        //then prints the user input out
        System.out.println("The number you have entered: " + num);

        scanner.close();

    
        
    }
}
