/*
    Contains the implementation of the basic functions declared in cstk.h file.
    Daniel Yu
    cstk.c
    March 6, 2025
 * 
*/
#include "cstk.h"

// Creates a Stack with the given maximal capacity
Stack *stk_create(int capacity) {
    Stack *stk = (Stack *)malloc(sizeof(Stack));
    stk->data = (int *)malloc(capacity * sizeof(int));
    stk->top = stk->data; // Initially, the stack is empty
    stk->capacity = capacity;
    return stk;
}

// Returns 1 if the Stack is empty, otherwise 0
int stk_empty(Stack *stk) {
    return (stk->top == stk->data);
}

// Returns 1 if the Stack is full, otherwise 0
int stk_full(Stack *stk) {
    return (stk->top == stk->data + stk->capacity);
}

// Pushes a new value onto the stack if there's space
void stk_push(Stack *stk, int value) {
    if (stk_full(stk)) {
        printf("Stack is full! Cannot push %d.\n", value);
        return;
    }
    *(stk->top) = value; // Store value at the top
    stk->top++; // Move top pointer forward
}

// Returns the value on the top of the stack without removing it
int stk_peek(Stack *stk) {
    if (stk_empty(stk)) {
        printf("Stack is empty! Cannot peek.\n");
        return 0;
    }
    return *(stk->top - 1); // Return the last inserted value
}

// Removes and returns the value on the top of the stack
int stk_pop(Stack *stk) {
    if (stk_empty(stk)) {
        printf("Stack is empty! Cannot pop.\n");
        return 0;
    }
    stk->top--; // Move top pointer back
    return *(stk->top); // Return popped value
}

// Displays the stack in LILO (1) or LIFO (0) order
void stk_display(Stack *stk, int order) {
    if (stk_empty(stk)) {
        printf("Stack is empty!\n");
        return;
    }

    printf("Stack contents:\n");
    if (order == 1) { // LILO: print from bottom to top
        for (int *ptr = stk->data; ptr < stk->top; ptr++)
            printf("%d ", *ptr);
    } else { // LIFO: print from top to bottom
        for (int *ptr = stk->top - 1; ptr >= stk->data; ptr--)
            printf("%d ", *ptr);
    }
    printf("\n");
}

// Frees up the memory used by the stack
void stk_destroy(Stack *stk) {
    if (stk) {
        free(stk->data);
        free(stk);
    }
}

// Copies the contents into another Stack of the same maximal size and returns it
Stack *stk_copy(Stack *stk) {
    if (!stk) {
        printf("Cannot copy a NULL stack.\n");
        return NULL;
    }

    Stack *new_stk = stk_create(stk->capacity);
    if (!new_stk) return NULL; // Memory allocation failure

    int size = stk->top - stk->data; // Number of elements in original stack
    for (int i = 0; i < size; i++)
        new_stk->data[i] = stk->data[i];

    new_stk->top = new_stk->data + size;
    return new_stk;
}
