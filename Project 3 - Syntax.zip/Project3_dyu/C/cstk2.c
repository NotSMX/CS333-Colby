/*
    Contains the implementation of the basic functions declared in cstk2.h file.
    Daniel Yu
    cstk2.c
    March 6, 2025
 * 
*/
#include "cstk2.h"

/**
 * @brief Creates a new Stack with the given capacity.
 *
 * @param capacity The maximal number of items in the Stack.
 * @return A pointer to the newly created Stack.
 */
Stack *stk_create(int capacity) {
    if (capacity <= 0) {
        printf("Invalid stack capacity.\n");
        return NULL;
    }

    Stack *stack = (Stack *)malloc(sizeof(Stack));
    if (!stack) {
        printf("Memory allocation failed for stack.\n");
        return NULL;
    }

    stack->data = (void **)malloc(sizeof(void *) * capacity);
    if (!stack->data) {
        printf("Memory allocation failed for stack data.\n");
        free(stack);
        return NULL;
    }

    stack->capacity = capacity;
    stack->top = stack->data; // Initially, the stack is empty

    return stack;
}

/**
 * @brief Frees all space allocated for the Stack.
 * @param stack A reference to the Stack to be freed.
 */
void stk_destroy(Stack *stack) {
    if (stack) {
        free(stack->data);
        free(stack);
    }
}

/**
 * @brief Returns the number of items in the given Stack.
 * @param stack The Stack to be inspected.
 * @return The number of items in the Stack.
 */
int stk_size(Stack *stack) {
    if (!stack) return 0;
    return stack->top - stack->data;
}

/**
 * @brief Adds an item to the stack.
 * @param stack The stack to add the item to.
 * @param item The item to add.
 */
void stk_push(Stack *stack, void *item) {
    if (!stack || stk_size(stack) >= stack->capacity) {
        printf("Stack is full or invalid. Cannot push.\n");
        return;
    }
    *(stack->top) = item; // Store the new item
    stack->top++; // Move top pointer forward
}

/**
 * @brief Returns the top item of the stack without removing it.
 * @param stack The Stack to peek at.
 * @return A reference to the item on top of the Stack.
 */
void *stk_peek(Stack *stack) {
    if (!stack || stk_size(stack) == 0) {
        printf("Stack is empty! Cannot peek.\n");
        return NULL;
    }
    return *(stack->top - 1);
}

/**
 * @brief Removes the top item from the stack and returns it.
 * @param stack The Stack to pop from.
 * @return The item removed from the Stack.
 */
void *stk_pop(Stack *stack) {
    if (!stack || stk_size(stack) == 0) {
        printf("Stack is empty! Cannot pop.\n");
        return NULL;
    }
    stack->top--; // Move top pointer back
    return *(stack->top); // Return popped item
}

/**
 * @brief Returns a reference to a String representing the contents of the
 * Stack. Uses the given toString function to compute string representations of
 * individual items, putting a ", " in between each sequential item.
 * @param stack the Stack to represent via a String.
 * @param toString a function that reads individual items of the stack and
 * returns string representations.
 * @return a String representing the contents of the Stack.
 */
char *stk_toString(Stack *stack, char *(*toString)(void *));
char *stk_toString(Stack *stack, char *(*toString)(void *)) {
    if (!stack) return strdup("Stack is NULL");

    int size = stk_size(stack);
    if (size == 0) return strdup("Stack is empty");

    // First, estimate required space: Allow 32 bytes per item initially
    int capacity = size * 32;
    char *result = (char *)malloc(capacity);
    if (!result) {
        printf("Memory allocation failed for stack string.\n");
        return NULL;
    }
    result[0] = '\0'; // Empty string initially

    for (int i = 0; i < size; i++) {
        char *itemStr = toString(stack->data[i]);
        int len = strlen(itemStr);

        // Reallocate if necessary
        if (strlen(result) + len + 2 >= capacity) {
            capacity *= 2;
            result = (char *)realloc(result, capacity);
            if (!result) {
                printf("Memory reallocation failed.\n");
                return NULL;
            }
        }

        strcat(result, itemStr);
        if (i < size - 1) strcat(result, ", ");
        free(itemStr); // Free temporary string
    }

    return result;
}