/*
    Locating Memory Addresses in cstk2.c
    Daniel Yu
    toDraw2.c
    March 6, 2025
 * 
*/
#include "cstk2.h"

typedef struct Account {
    char *name;
    int balance;
} Account;

int main() {
    Stack *stack = stk_create(10);
    int i;
    for (i = 0; i < 5; i++) {
        int *x = (int *)malloc(sizeof(int));
        *x = i;
        printf("x: %p\n", x);
        stk_push(stack, x);
    }
    printf("Stack (the variable itself) is at: %p\n", &stack);
    printf("Stack structure is allocated at: %p\n", stack);
    printf("Stack top pointer is at: %p\n", stack->top);
    printf("Stack data pointer is at: %p\n", stack->data);
	printf( "i is at %p\n", &i );

    Account account = {"Max Bender", 10};
    printf("Account: %p\n", &account);
    stk_push(stack, &account);

    // MARK 1 - draw current contents of stack and relevant contents of heap
    return 0;
}