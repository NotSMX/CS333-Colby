#ifndef CSTK_H
#define CSTK_H

#include <stdio.h>
#include <stdlib.h>

// Stack structure definition
typedef struct Stack {
    int *data;     // Pointer to the stack's data array
    int *top;      // Pointer to the next available position in the stack
    int capacity;  // Maximum capacity of the stack
} Stack;

// Function declarations

// Creates a Stack with the given maximal capacity
Stack *stk_create(int capacity);

// Returns 1 if the Stack is empty, otherwise 0
int stk_empty(Stack *stk);

// Returns 1 if the Stack is full, otherwise 0
int stk_full(Stack *stk);

// Pushes a new value onto the stack if there's space
void stk_push(Stack *stk, int value);

// Returns the value on the top of the stack without removing it
int stk_peek(Stack *stk);

// Removes and returns the value on the top of the stack
int stk_pop(Stack *stk);

// Displays the stack in LILO (1) or LIFO (0) order
void stk_display(Stack *stk, int order);

// Frees up the memory used by the stack
void stk_destroy(Stack *stk);

// Copies the contents into another Stack of the same maximal s
Stack *stk_copy(Stack *);
#endif