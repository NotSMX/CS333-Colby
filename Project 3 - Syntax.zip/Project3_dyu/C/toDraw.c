/*
    Locating Memory Addresses in cstk.c
    Daniel Yu
    toDraw.c
    March 6, 2025
 * 
*/
#include "cstk.h"
#include <stdio.h>
#include <stdlib.h>

int main (int argc, char **argv) {
    Stack *s = stk_create(20);

    
    int i;
    for(i = 0; i < 10; i++) {
        stk_push(s, i+1);
    } 
    // Mark 1 (First Memory Picture)
	printf("Stack (the variable itself) is at: %p\n", &s);
    printf("Stack structure is allocated at: %p\n", s);
    printf("Stack top pointer is at: %p\n", s->top);
    printf("Stack data pointer is at: %p\n", s->data);
	printf( "i is at %p\n", &i );

    printf("The original list: ");
    stk_display(s, 0);

    printf("The reversed list: ");
    stk_display(s, 1);

    stk_destroy(s);
    // Mark 2 (Second Memory Picture)
    printf("=============MARK 2=============\n");
    printf("Stack (the variable itself) is at: %p\n", &s);
    printf("Stack structure is allocated at: %p\n", s);
    printf("Stack top pointer is at: %p\n", s->top);
    printf("Stack data pointer is at: %p\n", s->data);
	printf( "i is at %p\n", &i );
	

    return 0;
}
