#ifndef MY_TIMING_H

#define MY_TIMING_H

// Return the time in seconds
// Note to Stephanie: it doesn't work to return a float - it must be
// a double.
double get_time_sec();

#endif
