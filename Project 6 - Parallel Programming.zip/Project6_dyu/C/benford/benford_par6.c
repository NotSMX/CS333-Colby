/**
 * 
 * Use a global variable that is an array of ints with 10*NUMTHREADS entries. The digit counts for each thread should be stored in that array. 
 * For this version store the counts from all the threads for a single digit together 
 * (e.g. entries 0 through NUMTHREADS-1 are used to keep track of the number of 0's, entries NUMTHREADS through 2*NUMTHREADS-1 are used to keep track of the number of 1's, etc.). 
 * Again, because each thread has its own section of the array, there is no need for a mutex! After all the threads have joined, loop through this new array of arrays, and sum the counts for each digit.
 * 
 * Daniel Yu
 * April 23, 2025
*/

#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <math.h>
#include <string.h>
#include "my_timing.h"

#define NUM_THREADS 8

int N = 0;
double *data;
int global_counts[10 * NUM_THREADS] = {0};

int loadData(char *filename) {
  FILE *fp;
  if (filename != NULL && strlen(filename))
    fp = fopen(filename, "r");
  else return -1;

  if (!fp) return -1;

  fread(&N, sizeof(int), 1, fp);
  data = (double*)malloc(sizeof(double) * N);
  fread(data, sizeof(double), N, fp);
  fclose(fp);
  return 1;
}

int leadingDigit(double n) {
  if (fabs(n) == 1.0) return 1;
  else if (fabs(n) == 0.0) return 0;
  else if (fabs(n) < 1.0) {
    double tmp = fabs(n);
    while (tmp < 1.0) tmp *= 10.0;
    return (int)floor(tmp);
  } else {
    long long unsigned in = (long long unsigned)floor(fabs(n));
    while (in > 9) in /= 10;
    return in;
  }
}

typedef struct {
  int start;
  int end;
  int tid;
} ThreadArgs;

void* thread_func(void* arg) {
  ThreadArgs* args = (ThreadArgs*)arg;

  for (int i = args->start; i < args->end; i++) {
    int d = leadingDigit(data[i]);
    if (d >= 1 && d <= 9) {
      global_counts[d * NUM_THREADS + args->tid]++;
    }
  }

  return NULL;
}

int main(int argc, char* argv[]) {
  if (argc != 2) {
    printf("Usage: %s <datafile>\n", argv[0]);
    return -1;
  }

  if (!loadData(argv[1])) {
    printf("Failed to load data.\n");
    return -1;
  }

  double t1 = get_time_sec();

  pthread_t threads[NUM_THREADS];
  ThreadArgs args[NUM_THREADS];
  int chunk = N / NUM_THREADS;

  for (int i = 0; i < NUM_THREADS; i++) {
    args[i].start = i * chunk;
    args[i].end = (i == NUM_THREADS - 1) ? N : (i + 1) * chunk;
    args[i].tid = i;
    pthread_create(&threads[i], NULL, thread_func, &args[i]);
  }

  for (int i = 0; i < NUM_THREADS; i++) {
    pthread_join(threads[i], NULL);
  }

  int final_counts[10] = {0};
  for (int d = 1; d <= 9; d++) {
    for (int tid = 0; tid < NUM_THREADS; tid++) {
      final_counts[d] += global_counts[d * NUM_THREADS + tid];
    }
  }

  double t2 = get_time_sec();

  for (int d = 1; d <= 9; d++) {
    printf("There are %d %d's\n", final_counts[d], d);
  }

  printf("It took %f seconds for the whole thing to run\n", t2 - t1);

  free(data);
  return 0;
}
