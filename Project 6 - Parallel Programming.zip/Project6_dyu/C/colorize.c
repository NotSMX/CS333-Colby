/**
 * 
 * Write a program that reads an image and applies a pixel-wise operator to it. Use parallelism to reduce the computation time. 
 * Your code should support 1, 2, and 4 threads.
 * 
 * Daniel Yu
 * April 23, 2025
*/

#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <sys/time.h>
#include "ppmIO.h"

typedef struct {
    Pixel *image;
    int start;
    int end;
} ThreadData;

int numThreads = 1;

double get_time_sec() {
    struct timeval t;
    gettimeofday(&t, NULL);
    return t.tv_sec + t.tv_usec * 1e-6;
}

void* colorize_chunk(void *arg) {
    ThreadData *data = (ThreadData*) arg;
    for (int i = data->start; i < data->end; i++) {
        data->image[i].r = data->image[i].r > 128 ? (220 + data->image[i].r) / 2 : (30 + data->image[i].r) / 2;
        data->image[i].g = data->image[i].g > 128 ? (220 + data->image[i].g) / 2 : (30 + data->image[i].g) / 2;
        data->image[i].b = data->image[i].b > 128 ? (220 + data->image[i].b) / 2 : (30 + data->image[i].b) / 2;
    }
    return NULL;
}

int main(int argc, char *argv[]) {
    Pixel *src;
    int rows, cols, colors;

    if (argc < 3) {
        printf("Usage: %s <image filename> <numThreads>\n", argv[0]);
        exit(-1);
    }

    numThreads = atoi(argv[2]);
    if (numThreads != 1 && numThreads != 2 && numThreads != 4) {
        printf("Please use 1, 2, or 4 threads.\n");
        exit(-1);
    }

    src = ppm_read(&rows, &cols, &colors, argv[1]);
    if (!src) {
        printf("Unable to read file %s\n", argv[1]);
        exit(-1);
    }

    int totalPixels = rows * cols;
    pthread_t threads[numThreads];
    ThreadData tData[numThreads];
    int chunk = totalPixels / numThreads;

    double t1 = get_time_sec();

    for (int i = 0; i < numThreads; i++) {
        tData[i].image = src;
        tData[i].start = i * chunk;
        tData[i].end = (i == numThreads - 1) ? totalPixels : (i + 1) * chunk;
        pthread_create(&threads[i], NULL, colorize_chunk, &tData[i]);
    }

    for (int i = 0; i < numThreads; i++) {
        pthread_join(threads[i], NULL);
    }

    double t2 = get_time_sec();
    printf("Colorize with %d thread(s) took %.6f seconds\n", numThreads, t2 - t1);

    ppm_write(src, rows, cols, colors, "bold.ppm");
    free(src);

    return 0;
}
