/**
 * 
 * Write some other useful routine that would be good to parallelize, such as matrix multiplication or an image filter.
 * 
 * Daniel Yu
 * April 23, 2025
*/

#include <stdio.h>
#include <stdlib.h>
#include <omp.h>

void multiply_matrices_parallel(int *A, int *B, int *C, int N) {
    #pragma omp parallel for
    for (int i = 0; i < N; i++) {
        for (int j = 0; j < N; j++) {
            C[i * N + j] = 0;
            for (int k = 0; k < N; k++) {
                C[i * N + j] += A[i * N + k] * B[k * N + j];
            }
        }
    }
}

int main() {
    int N = 4; // Size of the matrix
    int A[16] = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16};
    int B[16] = {16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1};
    int C[16];

    multiply_matrices_parallel(A, B, C, N);

    // Print the result
    for (int i = 0; i < N; i++) {
        for (int j = 0; j < N; j++) {
            printf("%d ", C[i * N + j]);
        }
        printf("\n");
    }

    return 0;
}
