/**
 * 
 * We have a shared counter that each thread increments.
 * Without a lock, multiple threads might read and write the counter simultaneously, leading to missed updates (race condition).
 * The pthread_mutex_lock ensures only one thread can increment counter at a time.
 * We expect the final result to be exactly NUM_THREADS * NUM_INCREMENTS.
 * 
 * Daniel Yu
 * April 23, 2025
*/


#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>

#define NUM_THREADS 4
#define NUM_INCREMENTS 100000

int counter = 0;                  // Shared resource
pthread_mutex_t lock;            // Mutex to protect the counter

void* increment(void* arg) {
    for (int i = 0; i < NUM_INCREMENTS; i++) {
        pthread_mutex_lock(&lock);      // 🔐 Enter critical section
        counter++;
        pthread_mutex_unlock(&lock);    // 🔓 Leave critical section
    }
    return NULL;
}

int main() {
    pthread_t threads[NUM_THREADS];

    // Initialize the mutex
    if (pthread_mutex_init(&lock, NULL) != 0) {
        perror("Mutex init failed");
        return 1;
    }

    // Create threads
    for (int i = 0; i < NUM_THREADS; i++) {
        pthread_create(&threads[i], NULL, increment, NULL);
    }

    // Join threads
    for (int i = 0; i < NUM_THREADS; i++) {
        pthread_join(threads[i], NULL);
    }

    // Clean up
    pthread_mutex_destroy(&lock);

    // Print final counter value
    printf("Final counter value: %d (Expected: %d)\n", counter, NUM_THREADS * NUM_INCREMENTS);

    return 0;
}
