/**
 * 
 * Write a program that reads an image and applies a pixel-wise operator to it. Use parallelism to reduce the computation time. 
 * Your code should support 1, 2, and 4 threads.
 * 
 * Daniel Yu
 * April 23, 2025
*/

const fs = require('fs');
const { Worker, isMainThread, parentPort, workerData } = require('worker_threads');

function readPPM(filename) {
    const data = fs.readFileSync(filename);
    const header = data.toString('ascii', 0, 15).match(/P6\s+(\d+)\s+(\d+)\s+(\d+)/);
    const width = parseInt(header[1]);
    const height = parseInt(header[2]);
    const maxVal = parseInt(header[3]);
    const headerLength = data.indexOf(0x0A, data.indexOf(header[0]) + header[0].length) + 1;
    const pixelData = data.slice(headerLength);

    return { width, height, maxVal, pixels: pixelData };
}

function writePPM(filename, width, height, maxVal, pixels) {
    const header = `P6\n${width} ${height}\n${maxVal}\n`;
    fs.writeFileSync(filename, header);
    fs.appendFileSync(filename, pixels);
}

function processPixel(r, g, b) {
    return [
        r > 128 ? (220 + r) >> 1 : (30 + r) >> 1,
        g > 128 ? (220 + g) >> 1 : (30 + g) >> 1,
        b > 128 ? (220 + b) >> 1 : (30 + b) >> 1
    ];
}

function runParallel(pixels, numThreads, width, height, maxVal, callback) {
    const segmentSize = Math.floor(pixels.length / numThreads / 3) * 3;
    const promises = [];

    const startTime = performance.now();

    for (let i = 0; i < numThreads; i++) {
        const start = i * segmentSize;
        const end = (i === numThreads - 1) ? pixels.length : start + segmentSize;

        const segment = pixels.slice(start, end);
        promises.push(new Promise((resolve, reject) => {
            const worker = new Worker(__filename, {
                workerData: segment
            });
            worker.on('message', resolve);
            worker.on('error', reject);
        }));
    }

    Promise.all(promises).then(results => {
        const final = Buffer.concat(results);
        const endTime = performance.now();
        console.log(`Using ${numThreads} threads took ${(endTime - startTime) / 1000} seconds`);
        writePPM(`output_${numThreads}.ppm`, width, height, maxVal, final);
        callback();
    });
}

if (isMainThread) {
    const inputFile = process.argv[2] || "input.ppm";
    const threadCount = parseInt(process.argv[3]) || 1;

    const { width, height, maxVal, pixels } = readPPM(inputFile);

    runParallel(pixels, threadCount, width, height, maxVal, () => {});
} else {
    const inPixels = workerData;
    const outPixels = Buffer.alloc(inPixels.length);

    for (let i = 0; i < inPixels.length; i += 3) {
        const [r, g, b] = processPixel(inPixels[i], inPixels[i + 1], inPixels[i + 2]);
        outPixels[i] = r;
        outPixels[i + 1] = g;
        outPixels[i + 2] = b;
    }

    parentPort.postMessage(outPixels);
}
