/**
 * 
 * Compilable poetry in your selected language.
 * 
 * Daniel Yu
 * April 23, 2025
*/

let languages = ["C", "Python", "Java", "JavaScript", "C++"];
let gratitude = true;

for (let lang of languages) {
    console.log(`To ${lang}, my guide through logic deep,`);
    console.log(`You woke my mind from novice sleep.`);
    console.log(`From loops to stacks, from bits to bytes,`);
    console.log(`You taught me how to build new heights.\n`);
}

if (gratitude) {
    console.log("To lectures filled with insight bright,");
    console.log("To problem sets that kept me up at night.");
    console.log("To every bug that made me groan,");
    console.log("You've helped me make this craft my own.\n");

    console.log("So thank you all — classmates, profs, and friends,");
    console.log("This journey bends, but never ends.");
    console.log("With semicolon tears, we say goodbye,");
    console.log("But code lives on — go reach the sky.");
}
