# CS333 - Project 6 - README
### Daniel Yu
### 4/23/2025

***Google Sites Report: https://sites.google.com/colby.edu/dans-cs333/home?authuser=1 ***

## Directory Layout:
```
├── C
│   ├── IMG_4203.ppm
│   ├── benford
│   │   ├── benford_par1.c
│   │   ├── benford_par2.c
│   │   ├── benford_par3.c
│   │   ├── benford_par4.c
│   │   ├── benford_par5.c
│   │   ├── benford_par6.c
│   │   ├── benford_sequential.c
│   │   ├── longer.bin
│   │   ├── longer_nonBenford.bin
│   │   ├── medium.bin
│   │   ├── my_timing.c
│   │   ├── my_timing.h
│   │   └── super_short.bin
│   ├── bold.ppm
│   ├── colorize.c
│   ├── extension1.c
│   ├── extension2.c
│   ├── ppmIO.c
│   └── ppmIO.h
├── C++
│   ├── IMG_4203.ppm
│   ├── colorize.cpp
│   └── extension.cpp
├── Javascript
│   ├── IMG_4203.ppm
│   ├── colorize.js
│   └── extension.js
├── README.md
└── images
    ├── cextension1.png
    ├── ctask1.png
    └── ctask2.png
```
## OS and C compiler
OS: Microsoft Windows Version 24H2 (OS Build 26100.2894)
C compiler: gcc (Ubuntu 13.3.0-6ubuntu2~24.04) 13.3.0

## Part I 
### Task 1
**Compile:** $ gcc -o benford_par my_timing.c benford_par1.c -lpthread -lm
(Replace the digit in benford_par with the version you want to run)

**Run:** $ ./benford_par medium.bin

**Output:**
![Screenshot of task 1's Graphical Data ](images/ctask1.png)

**Conclusions:**
Version IV (Local Counter Array, with Final Update Protected by Array of Mutexes) had the best performance with the lowest average runtime.
Versions I and II, which rely heavily on mutexes, showed the highest runtimes, likely due to lock contention.
Thread-local counting (Versions III–VI) consistently outperformed shared counter strategies, especially when no mutexes were required.

**The Role of Mutex Locks:**
Mutexes are essential when multiple threads share and update the same resource. In Versions I and II, mutex locks were used to prevent race conditions when updating the global count array. However, this introduces locking overhead, particularly when all threads are frequently trying to acquire the same lock.

**When Should You Use a Mutex?**
You should use a mutex only when threads must write to shared memory, and correctness depends on synchronized access. In cases where data can be split such that each thread updates separate memory (as in Versions IV–VI), mutexes can and should be avoided to maximize performance.

### Task 2
**Compile:** $ gcc -o colorize -I. colorize.c ppmIO.c -lm -lpthread

**Run:** $ ./colorize IMG_4203.ppm 1
(Replace the last digit with 1, 2 or 4)

**Output:**
![Screenshot of task 1's Graphical Data ](images/ctask2.png)

**Analysis:** Parallel processing shows dramatic improvements in performance.
Going from 1 to 2 threads reduces average time by ~39.6%.
Going from 2 to 4 threads reduces time further by ~89.2%.
The speedup when using 4 threads is about 15.3× faster than the serial version.

## Part II
### Task 1

**Output:** Please see on Google Site: https://sites.google.com/colby.edu/dans-cs333/project-6-c?authuser=1

### Task 2
**Compile:** $ g++ -o colorize_cpp colorize.cpp -std=c++11

**Run:** $ ./colorize IMG_4203.ppm 1
(Replace the last digit with 1, 2 or 4)

**Output:** Please see on Google Site: https://sites.google.com/colby.edu/dans-cs333/project-6-c?authuser=1

## Extensions

### Extension 1
**Description**
Firstly, as always, I did all tasks in Part II for the second language I'm learning, Javascript.

**Run:** $ node colorize.js IMG_4203.ppm 1
(Replace the last digit with 1, 2 or 4)

**Output:** Please see on Google Site: https://sites.google.com/colby.edu/dans-cs333/project-6-javascript?authuser=1

### Extension 2
**Description**
One useful routine to parallelize in C is matrix multiplication. This can benefit significantly from parallelization, especially for large matrices, as each element in the resulting matrix can be computed independently. For this extension, I  parallelized matrix multiplication using OpenMP, which simplifies parallelization in C.

**Compile:** $ gcc -o extension extension1.c

**Run:** $ ./extension

**Output:**
![Screenshot of Matrix Multiplication's output](images/cextension1.png)

### Extension 3
**Description**
I decided to make a simple example in C that demonstrates the use of a mutex lock to control access to a critical section using pthread_mutex_t. This is essential when you have shared resources (like a counter, file, or buffer) that must not be accessed by multiple threads simultaneously to avoid race conditions.

**Compile:** $ gcc -o extension extension2.c

**Run:** $ ./extension

**Output:**
Final counter value: 400000 (Expected: 400000)

### Extension 4
**Description**
In C++, I made compilable poetry.

**Compile:** $ g++ -o extension extension.cpp

**Run:** $ ./extension

**Output:** Please see on Google Site: https://sites.google.com/colby.edu/dans-cs333/project-6-c?authuser=1

### Extension 5
**Description**
Finally, in Javascript, I made compilable poetry.

**Run:** $ node extension.js

**Output:** Please see on Google Site: https://sites.google.com/colby.edu/dans-cs333/project-6-javascript?authuser=1
