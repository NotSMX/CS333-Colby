/**
 * 
 * Compilable poetry in your selected language.
 * 
 * Daniel Yu
 * April 23, 2025
*/

#include <iostream>
#include <string>

int main() {
    std::string dream = "light";
    std::string code = "night";

    while (dream != "done") {
        if (code == "night") {
            std::cout << "I write some code, a loop, a fight," << std::endl;
            std::cout << "A variable spark, a screen so bright." << std::endl;
            code = "day";
        } else if (code == "day") {
            std::cout << "I chase a bug, it runs away," << std::endl;
            std::cout << "Through functions deep, it makes me stay." << std::endl;
            dream = "done";
        }
    }

    std::cout << "The build is clean, the tests all run," << std::endl;
    std::cout << "At last, I rest. My work is done." << std::endl;

    return 0;
}
