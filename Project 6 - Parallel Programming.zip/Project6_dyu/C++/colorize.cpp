/**
 * 
 * Write a program that reads an image and applies a pixel-wise operator to it. Use parallelism to reduce the computation time. 
 * Your code should support 1, 2, and 4 threads.
 * 
 * Daniel Yu
 * April 23, 2025
*/

#include <iostream>
#include <fstream>
#include <vector>
#include <thread>
#include <cmath>
#include <chrono>

using namespace std;

struct Pixel {
    unsigned char r, g, b;
};

// Function to read PPM P6 image
bool readPPM(const string& filename, vector<Pixel>& data, int& rows, int& cols, int& maxColor) {
    ifstream file(filename, ios::binary);
    if (!file) return false;

    string magic;
    file >> magic;
    if (magic != "P6") return false;

    file >> cols >> rows >> maxColor;
    file.get(); // consume newline

    data.resize(rows * cols);
    file.read(reinterpret_cast<char*>(data.data()), rows * cols * 3);

    return true;
}

// Function to write PPM P6 image
bool writePPM(const string& filename, const vector<Pixel>& data, int rows, int cols, int maxColor) {
    ofstream file(filename, ios::binary);
    if (!file) return false;

    file << "P6\n" << cols << " " << rows << "\n" << maxColor << "\n";
    file.write(reinterpret_cast<const char*>(data.data()), rows * cols * 3);

    return true;
}

// Colorize operation for a segment
void colorizeSegment(vector<Pixel>& data, int start, int end) {
    for (int i = start; i < end; ++i) {
        data[i].r = data[i].r > 128 ? (220 + data[i].r) / 2 : (30 + data[i].r) / 2;
        data[i].g = data[i].g > 128 ? (220 + data[i].g) / 2 : (30 + data[i].g) / 2;
        data[i].b = data[i].b > 128 ? (220 + data[i].b) / 2 : (30 + data[i].b) / 2;
    }
}

int main(int argc, char* argv[]) {
    if (argc < 2) {
        cout << "Usage: " << argv[0] << " <image.ppm> [threads]" << endl;
        return -1;
    }

    string filename = argv[1];
    int numThreads = (argc > 2) ? stoi(argv[2]) : 1;

    vector<Pixel> img;
    int rows, cols, maxColor;
    if (!readPPM(filename, img, rows, cols, maxColor)) {
        cerr << "Failed to load image!" << endl;
        return -1;
    }

    auto start = chrono::high_resolution_clock::now();

    int totalPixels = rows * cols;
    vector<thread> threads;
    int chunk = totalPixels / numThreads;

    for (int i = 0; i < numThreads; ++i) {
        int startIdx = i * chunk;
        int endIdx = (i == numThreads - 1) ? totalPixels : startIdx + chunk;
        threads.emplace_back(colorizeSegment, ref(img), startIdx, endIdx);
    }

    for (auto& t : threads) t.join();

    auto end = chrono::high_resolution_clock::now();
    chrono::duration<double> duration = end - start;
    cout << "Processing time with " << numThreads << " threads: " << duration.count() << " seconds" << endl;

    writePPM("bold_cpp.ppm", img, rows, cols, maxColor);
    return 0;
}
